import asyncio
from playwright.async_api import async_playwright
import json
import datetime
import os
import time
import re

async def get_us_travel_advisories():
    """
    使用Playwright抓取美国国务院旅行建议数据
    """
    print("开始抓取美国旅行建议数据...")
    
    async with async_playwright() as p:
        browser = await p.chromium.launch(headless=True)
        page = await browser.new_page()
        
        # 访问美国旅行建议页面
        await page.goto("https://travel.state.gov/content/travel/en/traveladvisories/traveladvisories.html/", timeout=60000)
        print("页面加载完成")
        
        # 等待页面加载完成
        await page.wait_for_load_state("networkidle")
        
        # 保存页面截图，用于调试
        await page.screenshot(path="us_page.png")
        
        # 保存页面HTML
        html_content = await page.content()
        with open("us_raw_data.html", "w", encoding="utf-8") as f:
            f.write(html_content)
        print("美国旅行建议原始数据已保存")
        
        # 尝试通过浏览器直接搜索相关信息
        print("尝试通过搜索获取美国旅行建议数据...")
        
        # 访问美国国务院旅行建议搜索页面
        await page.goto("https://travel.state.gov/content/travel/en/international-travel.html", timeout=60000)
        await page.wait_for_load_state("networkidle")
        
        # 保存页面HTML
        html_content = await page.content()
        with open("us_international_travel.html", "w", encoding="utf-8") as f:
            f.write(html_content)
        
        # 尝试获取国家列表和链接
        advisories = []
        
        # 搜索美国旅行建议的公开API或数据源
        await page.goto("https://travel.state.gov/content/travel/en/traveladvisories/traveladvisories.html", timeout=60000)
        await page.wait_for_load_state("networkidle")
        
        # 保存页面HTML
        html_content = await page.content()
        with open("us_advisories_page.html", "w", encoding="utf-8") as f:
            f.write(html_content)
        
        # 尝试获取页面上的国家列表
        country_links = await page.locator('a[href*="/content/travel/en/traveladvisories/traveladvisories/"]').all()
        
        for link in country_links:
            try:
                country_text = await link.text_content()
                country_url = await link.get_attribute('href')
                
                # 过滤掉非国家链接
                if country_text and not any(keyword in country_text.lower() for keyword in ['travel advisories', 'about us', 'contact us']):
                    # 提取国家名称
                    country_name = country_text.strip()
                    
                    # 访问国家详情页面获取风险等级和更新时间
                    if country_url:
                        country_page = await browser.new_page()
                        try:
                            await country_page.goto(country_url, timeout=30000)
                            await country_page.wait_for_load_state("networkidle")
                            
                            # 获取页面内容
                            page_content = await country_page.content()
                            
                            # 尝试提取风险等级
                            level_pattern = r"Level (\d+):.*?([A-Za-z\s]+)"
                            level_match = re.search(level_pattern, page_content)
                            level = f"Level {level_match.group(1)}: {level_match.group(2)}" if level_match else "Unknown"
                            
                            # 尝试提取更新时间
                            date_pattern = r"Last Update:\s*([A-Za-z]+\s+\d+,\s+\d{4})"
                            date_match = re.search(date_pattern, page_content)
                            update_date = date_match.group(1) if date_match else ""
                            
                            advisories.append({
                                "country": country_name,
                                "advisory_level": level,
                                "last_update": update_date,
                                "url": country_url
                            })
                            
                            print(f"已获取 {country_name} 的旅行建议")
                        except Exception as e:
                            print(f"获取 {country_name} 详情时出错: {str(e)}")
                            advisories.append({
                                "country": country_name,
                                "advisory_level": "Error fetching details",
                                "last_update": "",
                                "url": country_url,
                                "error": str(e)
                            })
                        finally:
                            await country_page.close()
            except Exception as e:
                print(f"处理国家链接时出错: {str(e)}")
        
        # 如果没有找到足够的国家数据，尝试使用备用方法
        if len(advisories) < 10:
            print("尝试备用方法获取美国旅行建议数据...")
            
            # 访问美国旅行建议JSON数据源（如果存在）
            try:
                await page.goto("https://travel.state.gov/etc/designs/travel/tsg-common/data/travel-advisories.json", timeout=30000)
                json_content = await page.content()
                
                # 尝试解析JSON
                json_text = await page.evaluate("document.body.textContent")
                json_data = json.loads(json_text)
                
                # 处理JSON数据
                if isinstance(json_data, dict) and "advisories" in json_data:
                    for country_data in json_data["advisories"]:
                        advisories.append({
                            "country": country_data.get("country", ""),
                            "advisory_level": country_data.get("level", ""),
                            "last_update": country_data.get("date", ""),
                            "url": country_data.get("url", "")
                        })
                    print(f"从JSON源获取了 {len(json_data['advisories'])} 条美国旅行建议数据")
            except Exception as e:
                print(f"尝试获取JSON数据时出错: {str(e)}")
        
        # 如果上述方法都失败，尝试从网络搜索获取信息
        if len(advisories) < 10:
            print("尝试从网络搜索获取美国旅行建议数据...")
            
            # 记录无法获取完整数据的情况
            advisories.append({
                "country": "DATA_EXTRACTION_FAILED",
                "advisory_level": "Unable to extract complete data automatically",
                "last_update": datetime.datetime.now().strftime("%Y-%m-%d"),
                "note": "需要手动检查页面结构或使用更复杂的抓取方法"
            })
        
        await browser.close()
        
        # 保存当前时间作为抓取时间
        current_time = datetime.datetime.now().strftime("%Y-%m-%d")
        
        result = {
            "source": "US",
            "fetch_date": current_time,
            "data": advisories
        }
        
        # 保存为JSON文件
        with open("us_advisories.json", "w", encoding="utf-8") as f:
            json.dump(result, f, ensure_ascii=False, indent=4)
            
        print(f"已提取 {len(advisories)} 条美国旅行建议数据")
        return result

async def get_uk_travel_advisories():
    """
    使用Playwright抓取英国外交部旅行建议数据
    """
    print("开始抓取英国旅行建议数据...")
    
    async with async_playwright() as p:
        browser = await p.chromium.launch(headless=True)
        page = await browser.new_page()
        
        # 访问英国旅行建议页面
        await page.goto("https://www.gov.uk/foreign-travel-advice", timeout=60000)
        print("页面加载完成")
        
        # 等待页面加载完成
        await page.wait_for_load_state("networkidle")
        
        # 保存页面截图，用于调试
        await page.screenshot(path="uk_page.png")
        
        # 保存页面HTML
        html_content = await page.content()
        with open("uk_raw_data.html", "w", encoding="utf-8") as f:
            f.write(html_content)
        print("英国旅行建议原始数据已保存")
        
        # 尝试获取国家列表
        advisories = []
        
        # 查找国家链接
        country_links = await page.locator('a[href^="/foreign-travel-advice/"]').all()
        
        for link in country_links:
            try:
                country_name = await link.text_content()
                country_url = await link.get_attribute('href')
                
                # 排除非国家链接
                if country_name and not any(keyword in country_name.lower() for keyword in ['foreign', 'travel', 'advice', 'countries', 'territories']):
                    # 访问国家详情页面获取风险等级和更新时间
                    country_page = await browser.new_page()
                    full_url = f"https://www.gov.uk{country_url}" if not country_url.startswith('http') else country_url
                    
                    try:
                        await country_page.goto(full_url, timeout=30000)
                        await country_page.wait_for_load_state("networkidle")
                        
                        # 尝试获取更新时间
                        update_date = ""
                        date_element = await country_page.locator('.app-c-important-metadata__item time').first()
                        if date_element:
                            update_date = await date_element.text_content()
                        else:
                            date_element = await country_page.locator('.updated-at time').first()
                            if date_element:
                                update_date = await date_element.text_content()
                        
                        # 尝试获取风险等级
                        advisory_level = "Information available on country page"
                        level_element = await country_page.locator('.govuk-warning-text__text').first()
                        if level_element:
                            advisory_level = await level_element.text_content()
                        else:
                            level_element = await country_page.locator('.call-to-action').first()
                            if level_element:
                                advisory_level = await level_element.text_content()
                        
                        advisories.append({
                            "country": country_name.strip(),
                            "advisory_level": advisory_level.strip(),
                            "last_update": update_date.strip(),
                            "url": full_url
                        })
                        
                        print(f"已获取 {country_name.strip()} 的旅行建议")
                    except Exception as e:
                        print(f"获取 {country_name.strip()} 详情时出错: {str(e)}")
                        advisories.append({
                            "country": country_name.strip(),
                            "advisory_level": "Error fetching details",
                            "last_update": "",
                            "url": full_url,
                            "error": str(e)
                        })
                    finally:
                        await country_page.close()
            except Exception as e:
                print(f"处理国家链接时出错: {str(e)}")
        
        await browser.close()
        
        # 保存当前时间作为抓取时间
        current_time = datetime.datetime.now().strftime("%Y-%m-%d")
        
        result = {
            "source": "UK",
            "fetch_date": current_time,
            "data": advisories
        }
        
        # 保存为JSON文件
        with open("uk_advisories.json", "w", encoding="utf-8") as f:
            json.dump(result, f, ensure_ascii=False, indent=4)
            
        print(f"已提取 {len(advisories)} 条英国旅行建议数据")
        return result

async def main():
    """
    主函数，重新抓取美国和英国的旅行建议数据
    """
    print("开始重新抓取美国和英国的旅行建议数据...")
    
    # 创建结果目录
    os.makedirs("results", exist_ok=True)
    
    # 重新抓取美国和英国数据
    us_data = await get_us_travel_advisories()
    print("美国数据抓取完成")
    
    uk_data = await get_uk_travel_advisories()
    print("英国数据抓取完成")
    
    print("美国和英国数据重新抓取完成")

if __name__ == "__main__":
    asyncio.run(main())
