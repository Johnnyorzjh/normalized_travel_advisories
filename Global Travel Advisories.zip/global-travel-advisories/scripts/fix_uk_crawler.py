import asyncio
from playwright.async_api import async_playwright
import json
import datetime
import os
import time
import re

async def get_uk_travel_advisories():
    """
    使用Playwright抓取英国外交部旅行建议数据 - 修复版
    """
    print("开始抓取英国旅行建议数据...")
    
    async with async_playwright() as p:
        browser = await p.chromium.launch(headless=True)
        page = await browser.new_page()
        
        # 访问英国旅行建议页面
        await page.goto("https://www.gov.uk/foreign-travel-advice", timeout=60000)
        print("页面加载完成")
        
        # 等待页面加载完成
        await page.wait_for_load_state("networkidle")
        
        # 保存页面截图，用于调试
        await page.screenshot(path="uk_page.png")
        
        # 保存页面HTML
        html_content = await page.content()
        with open("uk_raw_data.html", "w", encoding="utf-8") as f:
            f.write(html_content)
        print("英国旅行建议原始数据已保存")
        
        # 尝试获取国家列表
        advisories = []
        
        # 查找国家链接 - 修复版
        country_elements = await page.locator('a[href^="/foreign-travel-advice/"]').all()
        
        for element in country_elements:
            try:
                # 正确使用text_content()方法
                country_name = await element.text_content()
                # 正确使用get_attribute()方法
                country_url = await element.get_attribute('href')
                
                # 排除非国家链接
                if country_name and not any(keyword in country_name.lower() for keyword in ['foreign', 'travel', 'advice', 'countries', 'territories']):
                    # 访问国家详情页面获取风险等级和更新时间
                    country_page = await browser.new_page()
                    full_url = f"https://www.gov.uk{country_url}" if not country_url.startswith('http') else country_url
                    
                    try:
                        await country_page.goto(full_url, timeout=30000)
                        await country_page.wait_for_load_state("networkidle")
                        
                        # 尝试获取更新时间 - 修复版
                        update_date = ""
                        date_elements = await country_page.locator('.app-c-important-metadata__item time').all()
                        if date_elements and len(date_elements) > 0:
                            update_date = await date_elements[0].text_content()
                        else:
                            date_elements = await country_page.locator('.updated-at time').all()
                            if date_elements and len(date_elements) > 0:
                                update_date = await date_elements[0].text_content()
                        
                        # 尝试获取风险等级 - 修复版
                        advisory_level = "Information available on country page"
                        level_elements = await country_page.locator('.govuk-warning-text__text').all()
                        if level_elements and len(level_elements) > 0:
                            advisory_level = await level_elements[0].text_content()
                        else:
                            level_elements = await country_page.locator('.call-to-action').all()
                            if level_elements and len(level_elements) > 0:
                                advisory_level = await level_elements[0].text_content()
                        
                        # 尝试获取页面内容作为备用
                        page_content = await country_page.content()
                        
                        # 如果没有找到特定元素，尝试从页面内容中提取关键信息
                        if advisory_level == "Information available on country page":
                            # 尝试查找常见的警告词语
                            warning_patterns = [
                                r"(FCDO advises against all travel)",
                                r"(FCDO advises against all but essential travel)",
                                r"(The FCDO advises against all travel to)",
                                r"(The FCDO advises against all but essential travel to)"
                            ]
                            
                            for pattern in warning_patterns:
                                matches = re.findall(pattern, page_content)
                                if matches:
                                    advisory_level = matches[0]
                                    break
                        
                        advisories.append({
                            "country": country_name.strip(),
                            "advisory_level": advisory_level.strip(),
                            "last_update": update_date.strip(),
                            "url": full_url
                        })
                        
                        print(f"已获取 {country_name.strip()} 的旅行建议")
                    except Exception as e:
                        print(f"获取 {country_name.strip()} 详情时出错: {str(e)}")
                        advisories.append({
                            "country": country_name.strip(),
                            "advisory_level": "Error fetching details",
                            "last_update": "",
                            "url": full_url,
                            "error": str(e)
                        })
                    finally:
                        await country_page.close()
            except Exception as e:
                print(f"处理国家链接时出错: {str(e)}")
        
        await browser.close()
        
        # 保存当前时间作为抓取时间
        current_time = datetime.datetime.now().strftime("%Y-%m-%d")
        
        result = {
            "source": "UK",
            "fetch_date": current_time,
            "data": advisories
        }
        
        # 保存为JSON文件
        with open("uk_advisories.json", "w", encoding="utf-8") as f:
            json.dump(result, f, ensure_ascii=False, indent=4)
            
        print(f"已提取 {len(advisories)} 条英国旅行建议数据")
        return result

async def main():
    """
    主函数，重新抓取英国的旅行建议数据
    """
    print("开始重新抓取英国的旅行建议数据...")
    
    # 创建结果目录
    os.makedirs("results", exist_ok=True)
    
    # 重新抓取英国数据
    uk_data = await get_uk_travel_advisories()
    print("英国数据抓取完成")

if __name__ == "__main__":
    asyncio.run(main())
