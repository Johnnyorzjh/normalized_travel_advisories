import json
import os
import datetime

def load_json_file(file_path):
    """
    加载JSON文件，如果文件不存在或格式错误则返回空数据
    """
    try:
        with open(file_path, 'r', encoding='utf-8') as f:
            return json.load(f)
    except (FileNotFoundError, json.JSONDecodeError) as e:
        print(f"加载 {file_path} 时出错: {str(e)}")
        return {"source": os.path.basename(file_path).split('_')[0], "fetch_date": "", "data": []}

def extract_country_data(data_sources):
    """
    从所有数据源中提取国家数据并整合
    """
    # 创建国家字典，用于存储每个国家的数据
    countries = {}
    
    # 遍历所有数据源
    for source in data_sources:
        source_name = source.get("source", "Unknown")
        fetch_date = source.get("fetch_date", "")
        
        # 遍历数据源中的每个国家
        for country_data in source.get("data", []):
            country_name = country_data.get("country", "").strip()
            
            # 跳过非国家数据
            if not country_name or country_name in ["DATA_EXTRACTION_FAILED", "DATA_SOURCE_NOTE"]:
                continue
            
            # 如果国家不在字典中，则添加
            if country_name not in countries:
                countries[country_name] = {}
            
            # 添加该数据源的信息
            countries[country_name][source_name] = {
                "advisory_level": country_data.get("advisory_level", "").strip(),
                "last_update": country_data.get("last_update", "").strip(),
                "url": country_data.get("url", "")
            }
    
    return countries

def create_integrated_json(countries):
    """
    创建整合后的JSON数据
    """
    # 创建结果列表
    result = []
    
    # 遍历所有国家
    for country_name, sources in countries.items():
        country_entry = {
            "country": country_name,
            "sources": {}
        }
        
        # 添加每个数据源的信息
        for source_name, source_data in sources.items():
            country_entry["sources"][source_name] = source_data
        
        result.append(country_entry)
    
    # 按国家名称排序
    result.sort(key=lambda x: x["country"])
    
    return result

def main():
    """
    主函数，整合所有数据源
    """
    print("开始整合所有数据源...")
    
    # 加载所有数据源
    us_data = load_json_file("us_advisories.json")
    uk_data = load_json_file("uk_advisories.json")
    canada_data = load_json_file("canada_advisories.json")
    australia_data = load_json_file("australia_advisories.json")
    newzealand_data = load_json_file("newzealand_advisories.json")
    
    # 整合所有数据源
    data_sources = [us_data, uk_data, canada_data, australia_data, newzealand_data]
    
    # 提取国家数据
    countries = extract_country_data(data_sources)
    
    # 创建整合后的JSON数据
    integrated_data = create_integrated_json(countries)
    
    # 创建最终结果
    result = {
        "metadata": {
            "creation_date": datetime.datetime.now().strftime("%Y-%m-%d"),
            "sources": [
                {"name": "US", "url": "https://travel.state.gov/content/travel/en/traveladvisories/traveladvisories.html/", "fetch_date": us_data.get("fetch_date", "")},
                {"name": "UK", "url": "https://www.gov.uk/foreign-travel-advice", "fetch_date": uk_data.get("fetch_date", "")},
                {"name": "Canada", "url": "https://travel.gc.ca/travelling/advisories", "fetch_date": canada_data.get("fetch_date", "")},
                {"name": "Australia", "url": "https://www.smartraveller.gov.au/destinations", "fetch_date": australia_data.get("fetch_date", "")},
                {"name": "NewZealand", "url": "https://www.safetravel.govt.nz/destinations", "fetch_date": newzealand_data.get("fetch_date", "")}
            ],
            "notes": [
                "部分数据源可能使用备用数据，请参考各数据源的说明",
                "澳大利亚和新西兰数据由于技术原因使用备用数据，可能不完全准确",
                "美国数据源存在反爬机制，部分数据可能不完整"
            ]
        },
        "countries": integrated_data
    }
    
    # 保存整合后的数据
    with open("results/integrated_travel_advisories.json", "w", encoding="utf-8") as f:
        json.dump(result, f, ensure_ascii=False, indent=4)
    
    print(f"整合完成，共整合了 {len(integrated_data)} 个国家的数据")
    print("结果已保存到 results/integrated_travel_advisories.json")
    
    return result

if __name__ == "__main__":
    main()
