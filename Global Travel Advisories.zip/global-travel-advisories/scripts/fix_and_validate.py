import json
import os
import datetime

def fix_integrated_data():
    """
    修复整合后的JSON数据结构，确保数据完整性
    """
    print("开始修复整合后的JSON数据结构...")
    
    # 读取整合后的JSON文件
    try:
        with open("results/integrated_travel_advisories.json", "r", encoding="utf-8") as f:
            data = json.load(f)
    except Exception as e:
        print(f"读取整合后的JSON文件时出错: {e}")
        return False
    
    print(f"原始数据包含 {len(data)} 个键")
    
    # 检查数据结构是否正确
    if "countries" in data and isinstance(data["countries"], list):
        print("发现数据结构不正确，'countries'键包含列表数据")
        countries_data = data["countries"]
        
        # 创建新的数据结构
        new_data = {}
        
        # 处理每个国家的数据
        for country_entry in countries_data:
            if "country" in country_entry and "sources" in country_entry:
                country_name = country_entry["country"]
                sources_data = country_entry["sources"]
                
                # 将sources数据转换为字典格式
                new_data[country_name] = {}
                for source in sources_data:
                    if "source" in source:
                        source_name = source["source"]
                        new_data[country_name][source_name] = source
        
        print(f"修复后的数据包含 {len(new_data)} 个国家")
        
        # 保存修复后的数据
        with open("results/fixed_travel_advisories.json", "w", encoding="utf-8") as f:
            json.dump(new_data, f, ensure_ascii=False, indent=4)
        
        print("修复后的数据已保存到 results/fixed_travel_advisories.json")
        return "results/fixed_travel_advisories.json"
    else:
        # 尝试直接修复现有结构
        fixed_data = {}
        country_count = 0
        
        for key, value in data.items():
            if isinstance(value, dict):
                # 已经是正确的格式
                fixed_data[key] = value
                country_count += 1
            elif isinstance(value, list):
                # 需要转换为字典
                fixed_data[key] = {}
                for item in value:
                    if isinstance(item, dict) and "source" in item:
                        source_name = item["source"]
                        fixed_data[key][source_name] = item
                country_count += 1
        
        print(f"修复后的数据包含 {country_count} 个国家")
        
        # 保存修复后的数据
        with open("results/fixed_travel_advisories.json", "w", encoding="utf-8") as f:
            json.dump(fixed_data, f, ensure_ascii=False, indent=4)
        
        print("修复后的数据已保存到 results/fixed_travel_advisories.json")
        return "results/fixed_travel_advisories.json"

def validate_data(file_path):
    """
    校验整合后的JSON数据完整性和准确性
    """
    print(f"开始校验JSON数据: {file_path}")
    
    # 读取整合后的JSON文件
    try:
        with open(file_path, "r", encoding="utf-8") as f:
            data = json.load(f)
    except Exception as e:
        print(f"读取JSON文件时出错: {e}")
        return False
    
    # 检查数据源
    sources = ["US", "UK", "Canada", "Australia", "NewZealand"]
    
    # 统计信息
    total_countries = len(data)
    countries_with_all_sources = 0
    countries_with_missing_sources = {}
    countries_with_alternative_data = {}
    
    # 校验每个国家的数据
    for country, country_data in data.items():
        if not isinstance(country_data, dict):
            print(f"警告: 国家 {country} 的数据不是字典格式")
            continue
            
        country_sources = set(country_data.keys())
        missing = [source for source in sources if source not in country_sources]
        
        if not missing:
            countries_with_all_sources += 1
        else:
            countries_with_missing_sources[country] = missing
        
        # 检查是否使用了备用数据
        for source, source_data in country_data.items():
            if isinstance(source_data, dict) and "note" in source_data and "备用数据" in source_data.get("note", ""):
                if country not in countries_with_alternative_data:
                    countries_with_alternative_data[country] = []
                countries_with_alternative_data[country].append(source)
    
    # 输出校验结果
    print(f"校验完成，共有 {total_countries} 个国家的数据")
    print(f"其中 {countries_with_all_sources} 个国家在所有数据源中都有数据")
    print(f"有 {len(countries_with_missing_sources)} 个国家在某些数据源中缺失数据")
    print(f"有 {len(countries_with_alternative_data)} 个国家使用了备用数据")
    
    # 保存校验结果
    validation_result = {
        "total_countries": total_countries,
        "countries_with_all_sources": countries_with_all_sources,
        "countries_with_missing_sources": countries_with_missing_sources,
        "countries_with_alternative_data": countries_with_alternative_data,
        "validation_date": datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    }
    
    with open("results/validation_result.json", "w", encoding="utf-8") as f:
        json.dump(validation_result, f, ensure_ascii=False, indent=4)
    
    print("校验结果已保存到 results/validation_result.json")
    return True

def create_summary_report():
    """
    创建数据摘要报告
    """
    print("开始创建数据摘要报告...")
    
    # 读取校验结果
    try:
        with open("results/validation_result.json", "r", encoding="utf-8") as f:
            validation_data = json.load(f)
    except Exception as e:
        print(f"读取校验结果时出错: {e}")
        return False
    
    # 读取整合后的数据
    try:
        with open("results/fixed_travel_advisories.json", "r", encoding="utf-8") as f:
            travel_data = json.load(f)
    except Exception as e:
        print(f"读取整合后的数据时出错: {e}")
        return False
    
    # 创建摘要报告
    report = {
        "report_date": datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        "data_sources": ["美国", "英国", "加拿大", "澳大利亚", "新西兰"],
        "total_countries": validation_data["total_countries"],
        "countries_with_all_sources": validation_data["countries_with_all_sources"],
        "countries_with_missing_sources_count": len(validation_data["countries_with_missing_sources"]),
        "countries_with_alternative_data_count": len(validation_data["countries_with_alternative_data"]),
        "high_risk_countries": [],
        "data_sample": {}
    }
    
    # 查找高风险国家（至少有3个数据源评级为最高风险）
    high_risk_keywords = ["Do not travel", "Level 4", "Avoid all travel", "不要旅行", "禁止旅行"]
    for country, country_data in travel_data.items():
        high_risk_count = 0
        for source, source_data in country_data.items():
            if isinstance(source_data, dict) and "advisory_level" in source_data:
                level = source_data["advisory_level"]
                if any(keyword in level for keyword in high_risk_keywords):
                    high_risk_count += 1
        
        if high_risk_count >= 3:
            report["high_risk_countries"].append(country)
    
    # 添加数据样本（前5个国家）
    sample_count = 0
    for country, country_data in travel_data.items():
        if sample_count < 5:
            report["data_sample"][country] = country_data
            sample_count += 1
    
    # 保存摘要报告
    with open("results/summary_report.json", "w", encoding="utf-8") as f:
        json.dump(report, f, ensure_ascii=False, indent=4)
    
    print("数据摘要报告已保存到 results/summary_report.json")
    
    # 创建人类可读的摘要报告
    human_report = f"""# 全球旅行建议数据摘要报告

## 报告概述
- 报告生成时间: {report["report_date"]}
- 数据来源: {", ".join(report["data_sources"])}
- 总国家数量: {report["total_countries"]}
- 在所有数据源中都有数据的国家数量: {report["countries_with_all_sources"]}
- 在某些数据源中缺失数据的国家数量: {report["countries_with_missing_sources_count"]}
- 使用备用数据的国家数量: {report["countries_with_alternative_data_count"]}

## 高风险国家
以下国家在至少3个数据源中被评为最高风险级别:
{", ".join(report["high_risk_countries"])}

## 数据说明
1. 本数据集整合了美国、英国、加拿大、澳大利亚和新西兰五个国家的官方旅行建议
2. 每个国家的旅行建议包含风险等级和更新时间
3. 由于各国使用不同的风险等级系统，数据未进行归一化处理
4. 部分数据源（如澳大利亚和新西兰）使用了备用数据，可能与官方数据有所差异

## 数据使用建议
1. 在规划旅行时，建议参考多个数据源的旅行建议
2. 对于高风险国家，建议谨慎考虑是否前往
3. 本数据仅供参考，实际旅行决策应以官方最新发布为准
4. 建议定期更新数据，确保获取最新的旅行建议

## 数据样例
以下是部分国家的旅行建议数据样例（仅供参考）:
"""
    
    # 添加数据样例
    for country, country_data in report["data_sample"].items():
        human_report += f"\n### {country}\n"
        for source, source_data in country_data.items():
            if isinstance(source_data, dict) and "advisory_level" in source_data and "last_update" in source_data:
                human_report += f"- {source}: {source_data['advisory_level']} (更新时间: {source_data['last_update']})\n"
    
    # 保存人类可读的摘要报告
    with open("results/summary_report.md", "w", encoding="utf-8") as f:
        f.write(human_report)
    
    print("人类可读的摘要报告已保存到 results/summary_report.md")
    return True

if __name__ == "__main__":
    # 修复整合后的数据结构
    fixed_file_path = fix_integrated_data()
    
    # 校验修复后的数据
    validate_data(fixed_file_path)
    
    # 创建摘要报告
    create_summary_report()
