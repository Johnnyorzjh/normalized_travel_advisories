import asyncio
from playwright.async_api import async_playwright
import json
import datetime
import os
import time
import re

async def get_uk_travel_advisories():
    """
    使用Playwright抓取英国外交部旅行建议数据 - 修复版
    """
    print("开始抓取英国旅行建议数据...")
    
    async with async_playwright() as p:
        browser = await p.chromium.launch(headless=True)
        page = await browser.new_page()
        
        # 访问英国旅行建议页面
        await page.goto("https://www.gov.uk/foreign-travel-advice", timeout=60000)
        print("页面加载完成")
        
        # 等待页面加载完成
        await page.wait_for_load_state("networkidle")
        
        # 保存页面截图，用于调试
        await page.screenshot(path="uk_page.png")
        
        # 保存页面HTML
        html_content = await page.content()
        with open("uk_raw_data.html", "w", encoding="utf-8") as f:
            f.write(html_content)
        print("英国旅行建议原始数据已保存")
        
        # 尝试获取国家列表
        advisories = []
        
        # 查找国家链接 - 修复版
        country_elements = await page.locator('a[href^="/foreign-travel-advice/"]').all()
        
        for element in country_elements:
            try:
                # 正确使用text_content()方法
                country_name = await element.text_content()
                # 正确使用get_attribute()方法
                country_url = await element.get_attribute('href')
                
                # 排除非国家链接
                if country_name and not any(keyword in country_name.lower() for keyword in ['foreign', 'travel', 'advice', 'countries', 'territories']):
                    # 访问国家详情页面获取风险等级和更新时间
                    country_page = await browser.new_page()
                    full_url = f"https://www.gov.uk{country_url}" if not country_url.startswith('http') else country_url
                    
                    try:
                        await country_page.goto(full_url, timeout=30000)
                        await country_page.wait_for_load_state("networkidle")
                        
                        # 尝试获取更新时间 - 修复版
                        update_date = ""
                        date_elements = await country_page.locator('.app-c-important-metadata__item time').all()
                        if date_elements and len(date_elements) > 0:
                            update_date = await date_elements[0].text_content()
                        else:
                            date_elements = await country_page.locator('.updated-at time').all()
                            if date_elements and len(date_elements) > 0:
                                update_date = await date_elements[0].text_content()
                        
                        # 尝试获取风险等级 - 修复版
                        advisory_level = "Information available on country page"
                        level_elements = await country_page.locator('.govuk-warning-text__text').all()
                        if level_elements and len(level_elements) > 0:
                            advisory_level = await level_elements[0].text_content()
                        else:
                            level_elements = await country_page.locator('.call-to-action').all()
                            if level_elements and len(level_elements) > 0:
                                advisory_level = await level_elements[0].text_content()
                        
                        # 尝试获取页面内容作为备用
                        page_content = await country_page.content()
                        
                        # 如果没有找到特定元素，尝试从页面内容中提取关键信息
                        if advisory_level == "Information available on country page":
                            # 尝试查找常见的警告词语
                            warning_patterns = [
                                r"(FCDO advises against all travel)",
                                r"(FCDO advises against all but essential travel)",
                                r"(The FCDO advises against all travel to)",
                                r"(The FCDO advises against all but essential travel to)"
                            ]
                            
                            for pattern in warning_patterns:
                                matches = re.findall(pattern, page_content)
                                if matches:
                                    advisory_level = matches[0]
                                    break
                        
                        advisories.append({
                            "country": country_name.strip(),
                            "advisory_level": advisory_level.strip(),
                            "last_update": update_date.strip(),
                            "url": full_url
                        })
                        
                        print(f"已获取 {country_name.strip()} 的旅行建议")
                    except Exception as e:
                        print(f"获取 {country_name.strip()} 详情时出错: {str(e)}")
                        advisories.append({
                            "country": country_name.strip(),
                            "advisory_level": "Error fetching details",
                            "last_update": "",
                            "url": full_url,
                            "error": str(e)
                        })
                    finally:
                        await country_page.close()
            except Exception as e:
                print(f"处理国家链接时出错: {str(e)}")
        
        await browser.close()
        
        # 保存当前时间作为抓取时间
        current_time = datetime.datetime.now().strftime("%Y-%m-%d")
        
        result = {
            "source": "UK",
            "fetch_date": current_time,
            "data": advisories
        }
        
        # 保存为JSON文件
        with open("uk_advisories.json", "w", encoding="utf-8") as f:
            json.dump(result, f, ensure_ascii=False, indent=4)
            
        print(f"已提取 {len(advisories)} 条英国旅行建议数据")
        return result

async def get_canada_travel_advisories():
    """
    使用Playwright抓取加拿大旅行建议数据
    """
    print("开始抓取加拿大旅行建议数据...")
    
    async with async_playwright() as p:
        browser = await p.chromium.launch(headless=True)
        page = await browser.new_page()
        
        # 访问加拿大旅行建议页面
        await page.goto("https://travel.gc.ca/travelling/advisories", timeout=60000)
        print("页面加载完成")
        
        # 等待页面加载完成
        await page.wait_for_load_state("networkidle")
        
        # 保存页面截图，用于调试
        await page.screenshot(path="canada_page.png")
        
        # 保存页面HTML
        html_content = await page.content()
        with open("canada_raw_data.html", "w", encoding="utf-8") as f:
            f.write(html_content)
        print("加拿大旅行建议原始数据已保存")
        
        # 尝试获取表格数据
        advisories = []
        
        # 检查是否有表格
        table_exists = await page.locator('table').count() > 0
        
        if table_exists:
            # 获取表格中的所有行
            rows = await page.locator('table tbody tr').all()
            
            for row in rows:
                # 获取行中的所有单元格
                cells = await row.locator('td').all()
                
                if len(cells) >= 2:
                    country = await cells[0].text_content()
                    level = await cells[1].text_content()
                    date = await cells[2].text_content() if len(cells) > 2 else ""
                    
                    advisories.append({
                        "country": country.strip(),
                        "advisory_level": level.strip(),
                        "last_update": date.strip()
                    })
        else:
            print("未找到表格，尝试其他选择器...")
            
            # 尝试查找其他可能包含数据的元素
            country_elements = await page.locator('.country-listing li, .advisory-country, a[href*="/destinations/"]').all()
            
            for element in country_elements:
                try:
                    country_link = await element.locator('a').first()
                    if country_link:
                        country = await country_link.text_content()
                        country_url = await country_link.get_attribute('href')
                        
                        # 访问国家详情页面获取风险等级和更新时间
                        if country_url:
                            country_page = await browser.new_page()
                            full_url = f"https://travel.gc.ca{country_url}" if not country_url.startswith('http') else country_url
                            
                            try:
                                await country_page.goto(full_url, timeout=30000)
                                await country_page.wait_for_load_state("networkidle")
                                
                                # 尝试获取风险等级
                                level_elements = await country_page.locator('.advisory-level, .risk-level').all()
                                level = await level_elements[0].text_content() if level_elements and len(level_elements) > 0 else "Unknown"
                                
                                # 尝试获取更新时间
                                date_elements = await country_page.locator('.date-modified, .advisory-date').all()
                                date = await date_elements[0].text_content() if date_elements and len(date_elements) > 0 else ""
                                
                                advisories.append({
                                    "country": country.strip(),
                                    "advisory_level": level.strip(),
                                    "last_update": date.strip(),
                                    "url": full_url
                                })
                                
                                print(f"已获取 {country.strip()} 的旅行建议")
                            except Exception as e:
                                print(f"获取 {country.strip()} 详情时出错: {str(e)}")
                                advisories.append({
                                    "country": country.strip(),
                                    "advisory_level": "Error fetching details",
                                    "last_update": "",
                                    "url": full_url,
                                    "error": str(e)
                                })
                            finally:
                                await country_page.close()
                except Exception as e:
                    print(f"处理国家元素时出错: {str(e)}")
        
        # 如果上述方法都失败，尝试直接从页面文本中提取信息
        if not advisories:
            print("尝试从页面文本中提取信息...")
            # 获取页面文本
            page_text = await page.text_content('body')
            
            # 记录页面无法直接解析的情况
            advisories.append({
                "country": "DATA_EXTRACTION_FAILED",
                "advisory_level": "Unable to extract data automatically",
                "last_update": datetime.datetime.now().strftime("%Y-%m-%d"),
                "note": "需要手动检查页面结构或使用更复杂的抓取方法"
            })
        
        await browser.close()
        
        # 保存当前时间作为抓取时间
        current_time = datetime.datetime.now().strftime("%Y-%m-%d")
        
        result = {
            "source": "Canada",
            "fetch_date": current_time,
            "data": advisories
        }
        
        # 保存为JSON文件
        with open("canada_advisories.json", "w", encoding="utf-8") as f:
            json.dump(result, f, ensure_ascii=False, indent=4)
            
        print(f"已提取 {len(advisories)} 条加拿大旅行建议数据")
        return result

async def get_australia_travel_advisories():
    """
    使用Playwright抓取澳大利亚旅行建议数据
    """
    print("开始抓取澳大利亚旅行建议数据...")
    
    async with async_playwright() as p:
        browser = await p.chromium.launch(headless=True)
        page = await browser.new_page()
        
        # 访问澳大利亚旅行建议页面
        await page.goto("https://www.smartraveller.gov.au/destinations", timeout=60000)
        print("页面加载完成")
        
        # 等待页面加载完成
        await page.wait_for_load_state("networkidle")
        
        # 保存页面截图，用于调试
        await page.screenshot(path="australia_page.png")
        
        # 保存页面HTML
        html_content = await page.content()
        with open("australia_raw_data.html", "w", encoding="utf-8") as f:
            f.write(html_content)
        print("澳大利亚旅行建议原始数据已保存")
        
        # 尝试获取国家列表
        advisories = []
        
        # 查找国家卡片或链接
        country_elements = await page.locator('.destination-card, .country-card, a[href*="/destinations/"]').all()
        
        for element in country_elements:
            try:
                # 获取国家名称
                country_name_elements = await element.locator('.destination-title, .country-name, h3').all()
                country_name = await country_name_elements[0].text_content() if country_name_elements and len(country_name_elements) > 0 else await element.text_content()
                
                # 获取风险等级
                level_elements = await element.locator('.alert-status, .risk-level, .advisory-level').all()
                level = await level_elements[0].text_content() if level_elements and len(level_elements) > 0 else "Unknown"
                
                # 获取链接
                country_url = await element.get_attribute('href')
                if not country_url:
                    link_elements = await element.locator('a').all()
                    if link_elements and len(link_elements) > 0:
                        country_url = await link_elements[0].get_attribute('href')
                
                # 如果有链接，访问详情页获取更新时间
                update_date = ""
                if country_url:
                    full_url = f"https://www.smartraveller.gov.au{country_url}" if not country_url.startswith('http') else country_url
                    
                    try:
                        country_page = await browser.new_page()
                        await country_page.goto(full_url, timeout=30000)
                        await country_page.wait_for_load_state("networkidle")
                        
                        # 尝试获取更新时间
                        date_elements = await country_page.locator('.last-updated, .date-modified, time').all()
                        if date_elements and len(date_elements) > 0:
                            update_date = await date_elements[0].text_content()
                        
                        await country_page.close()
                    except Exception as e:
                        print(f"获取 {country_name.strip()} 详情时出错: {str(e)}")
                        update_date = f"Error: {str(e)}"
                
                if country_name and not any(keyword in country_name.lower() for keyword in ['all destinations', 'browse all']):
                    advisories.append({
                        "country": country_name.strip(),
                        "advisory_level": level.strip(),
                        "last_update": update_date.strip(),
                        "url": full_url if country_url else ""
                    })
                    
                    print(f"已获取 {country_name.strip()} 的旅行建议")
            except Exception as e:
                print(f"处理国家元素时出错: {str(e)}")
        
        # 如果上述方法都失败，尝试直接从页面文本中提取信息
        if not advisories:
            print("尝试从页面文本中提取信息...")
            # 记录页面无法直接解析的情况
            advisories.append({
                "country": "DATA_EXTRACTION_FAILED",
                "advisory_level": "Unable to extract data automatically",
                "last_update": datetime.datetime.now().strftime("%Y-%m-%d"),
                "note": "需要手动检查页面结构或使用更复杂的抓取方法"
            })
        
        await browser.close()
        
        # 保存当前时间作为抓取时间
        current_time = datetime.datetime.now().strftime("%Y-%m-%d")
        
        result = {
            "source": "Australia",
            "fetch_date": current_time,
            "data": advisories
        }
        
        # 保存为JSON文件
        with open("australia_advisories.json", "w", encoding="utf-8") as f:
            json.dump(result, f, ensure_ascii=False, indent=4)
            
        print(f"已提取 {len(advisories)} 条澳大利亚旅行建议数据")
        return result

async def get_newzealand_travel_advisories():
    """
    使用Playwright抓取新西兰旅行建议数据
    """
    print("开始抓取新西兰旅行建议数据...")
    
    async with async_playwright() as p:
        browser = await p.chromium.launch(headless=True)
        page = await browser.new_page()
        
        # 访问新西兰旅行建议页面
        await page.goto("https://www.safetravel.govt.nz/destinations", timeout=60000)
        print("页面加载完成")
        
        # 等待页面加载完成
        await page.wait_for_load_state("networkidle")
        
        # 保存页面截图，用于调试
        await page.screenshot(path="newzealand_page.png")
        
        # 保存页面HTML
        html_content = await page.content()
        with open("newzealand_raw_data.html", "w", encoding="utf-8") as f:
            f.write(html_content)
        print("新西兰旅行建议原始数据已保存")
        
        # 尝试获取国家列表
        advisories = []
        
        # 查找国家链接
        country_elements = await page.locator('.destination-item, .country-item, a[href*="/destinations/"]').all()
        
        for element in country_elements:
            try:
                # 获取国家名称
                country_name = await element.text_content()
                
                # 获取链接
                country_url = await element.get_attribute('href')
                
                # 如果有链接，访问详情页获取风险等级和更新时间
                if country_url:
                    full_url = f"https://www.safetravel.govt.nz{country_url}" if not country_url.startswith('http') else country_url
                    
                    try:
                        country_page = await browser.new_page()
                        await country_page.goto(full_url, timeout=30000)
                        await country_page.wait_for_load_state("networkidle")
                        
                        # 尝试获取风险等级
                        level_elements = await country_page.locator('.risk-level, .advisory-level, .alert-status').all()
                        level = await level_elements[0].text_content() if level_elements and len(level_elements) > 0 else "Unknown"
                        
                        # 尝试获取更新时间
                        date_elements = await country_page.locator('.last-updated, .date-modified, time').all()
                        update_date = await date_elements[0].text_content() if date_elements and len(date_elements) > 0 else ""
                        
                        advisories.append({
                            "country": country_name.strip(),
                            "advisory_level": level.strip(),
                            "last_update": update_date.strip(),
                            "url": full_url
                        })
                        
                        print(f"已获取 {country_name.strip()} 的旅行建议")
                        await country_page.close()
                    except Exception as e:
                        print(f"获取 {country_name.strip()} 详情时出错: {str(e)}")
                        advisories.append({
                            "country": country_name.strip(),
                            "advisory_level": "Error fetching details",
                            "last_update": "",
                            "url": full_url,
                            "error": str(e)
                        })
                        await country_page.close()
            except Exception as e:
                print(f"处理国家元素时出错: {str(e)}")
        
        # 如果上述方法都失败，尝试直接从页面文本中提取信息
        if not advisories:
            print("尝试从页面文本中提取信息...")
            # 记录页面无法直接解析的情况
            advisories.append({
                "country": "DATA_EXTRACTION_FAILED",
                "advisory_level": "Unable to extract data automatically",
                "last_update": datetime.datetime.now().strftime("%Y-%m-%d"),
                "note": "需要手动检查页面结构或使用更复杂的抓取方法"
            })
        
        await browser.close()
        
        # 保存当前时间作为抓取时间
        current_time = datetime.datetime.now().strftime("%Y-%m-%d")
        
        result = {
            "source": "NewZealand",
            "fetch_date": current_time,
            "data": advisories
        }
        
        # 保存为JSON文件
        with open("newzealand_advisories.json", "w", encoding="utf-8") as f:
            json.dump(result, f, ensure_ascii=False, indent=4)
            
        print(f"已提取 {len(advisories)} 条新西兰旅行建议数据")
        return result

async def main():
    """
    主函数，依次抓取所有缺失的数据源
    """
    print("开始抓取缺失的旅行建议数据...")
    
    # 创建结果目录
    os.makedirs("results", exist_ok=True)
    
    # 检查并补全英国数据
    if not os.path.exists("uk_advisories.json"):
        print("英国数据文件缺失，开始抓取...")
        uk_data = await get_uk_travel_advisories()
        print("英国数据抓取完成")
    else:
        print("英国数据文件已存在")
    
    # 检查并补全加拿大数据
    if not os.path.exists("canada_advisories.json"):
        print("加拿大数据文件缺失，开始抓取...")
        canada_data = await get_canada_travel_advisories()
        print("加拿大数据抓取完成")
    else:
        print("加拿大数据文件已存在")
    
    # 检查并补全澳大利亚数据
    if not os.path.exists("australia_advisories.json"):
        print("澳大利亚数据文件缺失，开始抓取...")
        australia_data = await get_australia_travel_advisories()
        print("澳大利亚数据抓取完成")
    else:
        print("澳大利亚数据文件已存在")
    
    # 检查并补全新西兰数据
    if not os.path.exists("newzealand_advisories.json"):
        print("新西兰数据文件缺失，开始抓取...")
        newzealand_data = await get_newzealand_travel_advisories()
        print("新西兰数据抓取完成")
    else:
        print("新西兰数据文件已存在")
    
    print("所有缺失的数据文件抓取完成")

if __name__ == "__main__":
    asyncio.run(main())
