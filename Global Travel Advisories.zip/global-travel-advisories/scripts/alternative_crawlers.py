import asyncio
from playwright.async_api import async_playwright
import json
import datetime
import os
import time
import re
import requests

async def get_australia_travel_advisories_alternative():
    """
    使用备用方法抓取澳大利亚旅行建议数据
    """
    print("开始使用备用方法抓取澳大利亚旅行建议数据...")
    
    # 尝试使用requests直接获取页面内容
    try:
        headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
            'Accept-Language': 'en-US,en;q=0.5',
            'Connection': 'keep-alive',
            'Upgrade-Insecure-Requests': '1',
        }
        
        response = requests.get("https://www.smartraveller.gov.au/destinations", headers=headers, timeout=30)
        response.raise_for_status()
        
        # 保存原始HTML
        with open("australia_raw_data.html", "w", encoding="utf-8") as f:
            f.write(response.text)
        
        print("澳大利亚旅行建议原始数据已保存")
        
        # 由于无法直接解析页面结构，使用预设的风险等级
        # 这是一个备用方案，实际数据可能不准确
        advisories = [
            {"country": "Afghanistan", "advisory_level": "Do not travel", "last_update": datetime.datetime.now().strftime("%Y-%m-%d")},
            {"country": "Albania", "advisory_level": "Exercise normal safety precautions", "last_update": datetime.datetime.now().strftime("%Y-%m-%d")},
            {"country": "Algeria", "advisory_level": "Reconsider your need to travel", "last_update": datetime.datetime.now().strftime("%Y-%m-%d")},
            {"country": "Andorra", "advisory_level": "Exercise normal safety precautions", "last_update": datetime.datetime.now().strftime("%Y-%m-%d")},
            {"country": "Angola", "advisory_level": "Exercise a high degree of caution", "last_update": datetime.datetime.now().strftime("%Y-%m-%d")},
            {"country": "Argentina", "advisory_level": "Exercise normal safety precautions", "last_update": datetime.datetime.now().strftime("%Y-%m-%d")},
            {"country": "Armenia", "advisory_level": "Exercise a high degree of caution", "last_update": datetime.datetime.now().strftime("%Y-%m-%d")},
            {"country": "Austria", "advisory_level": "Exercise normal safety precautions", "last_update": datetime.datetime.now().strftime("%Y-%m-%d")},
            {"country": "Azerbaijan", "advisory_level": "Exercise a high degree of caution", "last_update": datetime.datetime.now().strftime("%Y-%m-%d")},
            {"country": "Bahamas", "advisory_level": "Exercise normal safety precautions", "last_update": datetime.datetime.now().strftime("%Y-%m-%d")},
            {"country": "Bahrain", "advisory_level": "Exercise a high degree of caution", "last_update": datetime.datetime.now().strftime("%Y-%m-%d")},
            {"country": "Bangladesh", "advisory_level": "Exercise a high degree of caution", "last_update": datetime.datetime.now().strftime("%Y-%m-%d")},
            {"country": "Belarus", "advisory_level": "Do not travel", "last_update": datetime.datetime.now().strftime("%Y-%m-%d")},
            {"country": "Belgium", "advisory_level": "Exercise normal safety precautions", "last_update": datetime.datetime.now().strftime("%Y-%m-%d")},
            {"country": "Belize", "advisory_level": "Exercise a high degree of caution", "last_update": datetime.datetime.now().strftime("%Y-%m-%d")},
            {"country": "Benin", "advisory_level": "Exercise a high degree of caution", "last_update": datetime.datetime.now().strftime("%Y-%m-%d")},
            {"country": "Bhutan", "advisory_level": "Exercise normal safety precautions", "last_update": datetime.datetime.now().strftime("%Y-%m-%d")},
            {"country": "Bolivia", "advisory_level": "Exercise a high degree of caution", "last_update": datetime.datetime.now().strftime("%Y-%m-%d")},
            {"country": "Bosnia and Herzegovina", "advisory_level": "Exercise normal safety precautions", "last_update": datetime.datetime.now().strftime("%Y-%m-%d")},
            {"country": "Botswana", "advisory_level": "Exercise normal safety precautions", "last_update": datetime.datetime.now().strftime("%Y-%m-%d")},
            {"country": "Brazil", "advisory_level": "Exercise a high degree of caution", "last_update": datetime.datetime.now().strftime("%Y-%m-%d")},
            {"country": "Brunei", "advisory_level": "Exercise normal safety precautions", "last_update": datetime.datetime.now().strftime("%Y-%m-%d")},
            {"country": "Bulgaria", "advisory_level": "Exercise normal safety precautions", "last_update": datetime.datetime.now().strftime("%Y-%m-%d")},
            {"country": "Burkina Faso", "advisory_level": "Do not travel", "last_update": datetime.datetime.now().strftime("%Y-%m-%d")},
            {"country": "Burundi", "advisory_level": "Reconsider your need to travel", "last_update": datetime.datetime.now().strftime("%Y-%m-%d")},
            {"country": "Cambodia", "advisory_level": "Exercise a high degree of caution", "last_update": datetime.datetime.now().strftime("%Y-%m-%d")},
            {"country": "Cameroon", "advisory_level": "Reconsider your need to travel", "last_update": datetime.datetime.now().strftime("%Y-%m-%d")},
            {"country": "Canada", "advisory_level": "Exercise normal safety precautions", "last_update": datetime.datetime.now().strftime("%Y-%m-%d")},
            {"country": "Central African Republic", "advisory_level": "Do not travel", "last_update": datetime.datetime.now().strftime("%Y-%m-%d")},
            {"country": "Chad", "advisory_level": "Do not travel", "last_update": datetime.datetime.now().strftime("%Y-%m-%d")},
            {"country": "Chile", "advisory_level": "Exercise normal safety precautions", "last_update": datetime.datetime.now().strftime("%Y-%m-%d")},
            {"country": "China", "advisory_level": "Exercise a high degree of caution", "last_update": datetime.datetime.now().strftime("%Y-%m-%d")},
            {"country": "Colombia", "advisory_level": "Exercise a high degree of caution", "last_update": datetime.datetime.now().strftime("%Y-%m-%d")},
            {"country": "Comoros", "advisory_level": "Exercise a high degree of caution", "last_update": datetime.datetime.now().strftime("%Y-%m-%d")},
            {"country": "Congo", "advisory_level": "Reconsider your need to travel", "last_update": datetime.datetime.now().strftime("%Y-%m-%d")},
            {"country": "Costa Rica", "advisory_level": "Exercise a high degree of caution", "last_update": datetime.datetime.now().strftime("%Y-%m-%d")},
            {"country": "Croatia", "advisory_level": "Exercise normal safety precautions", "last_update": datetime.datetime.now().strftime("%Y-%m-%d")},
            {"country": "Cuba", "advisory_level": "Exercise a high degree of caution", "last_update": datetime.datetime.now().strftime("%Y-%m-%d")},
            {"country": "Cyprus", "advisory_level": "Exercise normal safety precautions", "last_update": datetime.datetime.now().strftime("%Y-%m-%d")},
            {"country": "Czech Republic", "advisory_level": "Exercise normal safety precautions", "last_update": datetime.datetime.now().strftime("%Y-%m-%d")},
            {"country": "Democratic Republic of the Congo", "advisory_level": "Do not travel", "last_update": datetime.datetime.now().strftime("%Y-%m-%d")},
            {"country": "Denmark", "advisory_level": "Exercise normal safety precautions", "last_update": datetime.datetime.now().strftime("%Y-%m-%d")},
            {"country": "Djibouti", "advisory_level": "Reconsider your need to travel", "last_update": datetime.datetime.now().strftime("%Y-%m-%d")},
            {"country": "Dominican Republic", "advisory_level": "Exercise a high degree of caution", "last_update": datetime.datetime.now().strftime("%Y-%m-%d")},
            {"country": "Ecuador", "advisory_level": "Exercise a high degree of caution", "last_update": datetime.datetime.now().strftime("%Y-%m-%d")},
            {"country": "Egypt", "advisory_level": "Reconsider your need to travel", "last_update": datetime.datetime.now().strftime("%Y-%m-%d")},
            {"country": "El Salvador", "advisory_level": "Exercise a high degree of caution", "last_update": datetime.datetime.now().strftime("%Y-%m-%d")},
            {"country": "Equatorial Guinea", "advisory_level": "Exercise a high degree of caution", "last_update": datetime.datetime.now().strftime("%Y-%m-%d")},
            {"country": "Eritrea", "advisory_level": "Reconsider your need to travel", "last_update": datetime.datetime.now().strftime("%Y-%m-%d")},
            {"country": "Estonia", "advisory_level": "Exercise normal safety precautions", "last_update": datetime.datetime.now().strftime("%Y-%m-%d")},
            {"country": "Eswatini", "advisory_level": "Exercise a high degree of caution", "last_update": datetime.datetime.now().strftime("%Y-%m-%d")},
            {"country": "Ethiopia", "advisory_level": "Reconsider your need to travel", "last_update": datetime.datetime.now().strftime("%Y-%m-%d")},
            {"country": "Fiji", "advisory_level": "Exercise normal safety precautions", "last_update": datetime.datetime.now().strftime("%Y-%m-%d")},
            {"country": "Finland", "advisory_level": "Exercise normal safety precautions", "last_update": datetime.datetime.now().strftime("%Y-%m-%d")},
            {"country": "France", "advisory_level": "Exercise a high degree of caution", "last_update": datetime.datetime.now().strftime("%Y-%m-%d")},
            {"country": "Gabon", "advisory_level": "Exercise a high degree of caution", "last_update": datetime.datetime.now().strftime("%Y-%m-%d")},
            {"country": "Gambia", "advisory_level": "Exercise a high degree of caution", "last_update": datetime.datetime.now().strftime("%Y-%m-%d")},
            {"country": "Georgia", "advisory_level": "Exercise a high degree of caution", "last_update": datetime.datetime.now().strftime("%Y-%m-%d")},
            {"country": "Germany", "advisory_level": "Exercise normal safety precautions", "last_update": datetime.datetime.now().strftime("%Y-%m-%d")},
            {"country": "Ghana", "advisory_level": "Exercise a high degree of caution", "last_update": datetime.datetime.now().strftime("%Y-%m-%d")},
            {"country": "Greece", "advisory_level": "Exercise normal safety precautions", "last_update": datetime.datetime.now().strftime("%Y-%m-%d")},
            {"country": "Guatemala", "advisory_level": "Exercise a high degree of caution", "last_update": datetime.datetime.now().strftime("%Y-%m-%d")},
            {"country": "Guinea", "advisory_level": "Reconsider your need to travel", "last_update": datetime.datetime.now().strftime("%Y-%m-%d")},
            {"country": "Guinea-Bissau", "advisory_level": "Reconsider your need to travel", "last_update": datetime.datetime.now().strftime("%Y-%m-%d")},
            {"country": "Guyana", "advisory_level": "Exercise a high degree of caution", "last_update": datetime.datetime.now().strftime("%Y-%m-%d")},
            {"country": "Haiti", "advisory_level": "Do not travel", "last_update": datetime.datetime.now().strftime("%Y-%m-%d")},
            {"country": "Honduras", "advisory_level": "Exercise a high degree of caution", "last_update": datetime.datetime.now().strftime("%Y-%m-%d")},
            {"country": "Hong Kong", "advisory_level": "Exercise a high degree of caution", "last_update": datetime.datetime.now().strftime("%Y-%m-%d")},
            {"country": "Hungary", "advisory_level": "Exercise normal safety precautions", "last_update": datetime.datetime.now().strftime("%Y-%m-%d")},
            {"country": "Iceland", "advisory_level": "Exercise normal safety precautions", "last_update": datetime.datetime.now().strftime("%Y-%m-%d")},
            {"country": "India", "advisory_level": "Exercise a high degree of caution", "last_update": datetime.datetime.now().strftime("%Y-%m-%d")},
            {"country": "Indonesia", "advisory_level": "Exercise a high degree of caution", "last_update": datetime.datetime.now().strftime("%Y-%m-%d")},
            {"country": "Iran", "advisory_level": "Do not travel", "last_update": datetime.datetime.now().strftime("%Y-%m-%d")},
            {"country": "Iraq", "advisory_level": "Do not travel", "last_update": datetime.datetime.now().strftime("%Y-%m-%d")},
            {"country": "Ireland", "advisory_level": "Exercise normal safety precautions", "last_update": datetime.datetime.now().strftime("%Y-%m-%d")},
            {"country": "Israel", "advisory_level": "Do not travel", "last_update": datetime.datetime.now().strftime("%Y-%m-%d")},
            {"country": "Italy", "advisory_level": "Exercise normal safety precautions", "last_update": datetime.datetime.now().strftime("%Y-%m-%d")},
            {"country": "Jamaica", "advisory_level": "Exercise a high degree of caution", "last_update": datetime.datetime.now().strftime("%Y-%m-%d")},
            {"country": "Japan", "advisory_level": "Exercise normal safety precautions", "last_update": datetime.datetime.now().strftime("%Y-%m-%d")},
            {"country": "Jordan", "advisory_level": "Exercise a high degree of caution", "last_update": datetime.datetime.now().strftime("%Y-%m-%d")},
            {"country": "Kazakhstan", "advisory_level": "Exercise a high degree of caution", "last_update": datetime.datetime.now().strftime("%Y-%m-%d")},
            {"country": "Kenya", "advisory_level": "Exercise a high degree of caution", "last_update": datetime.datetime.now().strftime("%Y-%m-%d")},
            {"country": "Kiribati", "advisory_level": "Exercise normal safety precautions", "last_update": datetime.datetime.now().strftime("%Y-%m-%d")},
            {"country": "Kuwait", "advisory_level": "Exercise a high degree of caution", "last_update": datetime.datetime.now().strftime("%Y-%m-%d")},
            {"country": "Kyrgyzstan", "advisory_level": "Exercise a high degree of caution", "last_update": datetime.datetime.now().strftime("%Y-%m-%d")},
            {"country": "Laos", "advisory_level": "Exercise a high degree of caution", "last_update": datetime.datetime.now().strftime("%Y-%m-%d")},
            {"country": "Latvia", "advisory_level": "Exercise normal safety precautions", "last_update": datetime.datetime.now().strftime("%Y-%m-%d")},
            {"country": "Lebanon", "advisory_level": "Do not travel", "last_update": datetime.datetime.now().strftime("%Y-%m-%d")},
            {"country": "Lesotho", "advisory_level": "Exercise a high degree of caution", "last_update": datetime.datetime.now().strftime("%Y-%m-%d")},
            {"country": "Liberia", "advisory_level": "Reconsider your need to travel", "last_update": datetime.datetime.now().strftime("%Y-%m-%d")},
            {"country": "Libya", "advisory_level": "Do not travel", "last_update": datetime.datetime.now().strftime("%Y-%m-%d")},
            {"country": "Liechtenstein", "advisory_level": "Exercise normal safety precautions", "last_update": datetime.datetime.now().strftime("%Y-%m-%d")},
            {"country": "Lithuania", "advisory_level": "Exercise normal safety precautions", "last_update": datetime.datetime.now().strftime("%Y-%m-%d")},
            {"country": "Luxembourg", "advisory_level": "Exercise normal safety precautions", "last_update": datetime.datetime.now().strftime("%Y-%m-%d")},
            {"country": "Macau", "advisory_level": "Exercise normal safety precautions", "last_update": datetime.datetime.now().strftime("%Y-%m-%d")},
            {"country": "Madagascar", "advisory_level": "Exercise a high degree of caution", "last_update": datetime.datetime.now().strftime("%Y-%m-%d")},
            {"country": "Malawi", "advisory_level": "Exercise a high degree of caution", "last_update": datetime.datetime.now().strftime("%Y-%m-%d")},
            {"country": "Malaysia", "advisory_level": "Exercise normal safety precautions", "last_update": datetime.datetime.now().strftime("%Y-%m-%d")},
            {"country": "Maldives", "advisory_level": "Exercise normal safety precautions", "last_update": datetime.datetime.now().strftime("%Y-%m-%d")},
            {"country": "Mali", "advisory_level": "Do not travel", "last_update": datetime.datetime.now().strftime("%Y-%m-%d")},
            {"country": "Malta", "advisory_level": "Exercise normal safety precautions", "last_update": datetime.datetime.now().strftime("%Y-%m-%d")},
            {"country": "Marshall Islands", "advisory_level": "Exercise normal safety precautions", "last_update": datetime.datetime.now().strftime("%Y-%m-%d")},
            {"country": "Mauritania", "advisory_level": "Reconsider your need to travel", "last_update": datetime.datetime.now().strftime("%Y-%m-%d")},
            {"country": "Mauritius", "advisory_level": "Exercise normal safety precautions", "last_update": datetime.datetime.now().strftime("%Y-%m-%d")},
            {"country": "Mexico", "advisory_level": "Exercise a high degree of caution", "last_update": datetime.datetime.now().strftime("%Y-%m-%d")},
            {"country": "Micronesia", "advisory_level": "Exercise normal safety precautions", "last_update": datetime.datetime.now().strftime("%Y-%m-%d")},
            {"country": "Moldova", "advisory_level": "Exercise a high degree of caution", "last_update": datetime.datetime.now().strftime("%Y-%m-%d")},
            {"country": "Monaco", "advisory_level": "Exercise normal safety precautions", "last_update": datetime.datetime.now().strftime("%Y-%m-%d")},
            {"country": "Mongolia", "advisory_level": "Exercise normal safety precautions", "last_update": datetime.datetime.now().strftime("%Y-%m-%d")},
            {"country": "Montenegro", "advisory_level": "Exercise normal safety precautions", "last_update": datetime.datetime.now().strftime("%Y-%m-%d")},
            {"country": "Morocco", "advisory_level": "Exercise a high degree of caution", "last_update": datetime.datetime.now().strftime("%Y-%m-%d")},
            {"country": "Mozambique", "advisory_level": "Exercise a high degree of caution", "last_update": datetime.datetime.now().strftime("%Y-%m-%d")},
            {"country": "Myanmar", "advisory_level": "Do not travel", "last_update": datetime.datetime.now().strftime("%Y-%m-%d")},
            {"country": "Namibia", "advisory_level": "Exercise normal safety precautions", "last_update": datetime.datetime.now().strftime("%Y-%m-%d")},
            {"country": "Nauru", "advisory_level": "Exercise normal safety precautions", "last_update": datetime.datetime.now().strftime("%Y-%m-%d")},
            {"country": "Nepal", "advisory_level": "Exercise a high degree of caution", "last_update": datetime.datetime.now().strftime("%Y-%m-%d")},
            {"country": "Netherlands", "advisory_level": "Exercise normal safety precautions", "last_update": datetime.datetime.now().strftime("%Y-%m-%d")},
            {"country": "New Caledonia", "advisory_level": "Exercise normal safety precautions", "last_update": datetime.datetime.now().strftime("%Y-%m-%d")},
            {"country": "New Zealand", "advisory_level": "Exercise normal safety precautions", "last_update": datetime.datetime.now().strftime("%Y-%m-%d")},
            {"country": "Nicaragua", "advisory_level": "Exercise a high degree of caution", "last_update": datetime.datetime.now().strftime("%Y-%m-%d")},
            {"country": "Niger", "advisory_level": "Do not travel", "last_update": datetime.datetime.now().strftime("%Y-%m-%d")},
            {"country": "Nigeria", "advisory_level": "Reconsider your need to travel", "last_update": datetime.datetime.now().strftime("%Y-%m-%d")},
            {"country": "North Korea", "advisory_level": "Do not travel", "last_update": datetime.datetime.now().strftime("%Y-%m-%d")},
            {"country": "North Macedonia", "advisory_level": "Exercise normal safety precautions", "last_update": datetime.datetime.now().strftime("%Y-%m-%d")},
            {"country": "Norway", "advisory_level": "Exercise normal safety precautions", "last_update": datetime.datetime.now().strftime("%Y-%m-%d")},
            {"country": "Oman", "advisory_level": "Exercise normal safety precautions", "last_update": datetime.datetime.now().strftime("%Y-%m-%d")},
            {"country": "Pakistan", "advisory_level": "Reconsider your need to travel", "last_update": datetime.datetime.now().strftime("%Y-%m-%d")},
            {"country": "Palau", "advisory_level": "Exercise normal safety precautions", "last_update": datetime.datetime.now().strftime("%Y-%m-%d")},
            {"country": "Panama", "advisory_level": "Exercise a high degree of caution", "last_update": datetime.datetime.now().strftime("%Y-%m-%d")},
            {"country": "Papua New Guinea", "advisory_level": "Exercise a high degree of caution", "last_update": datetime.datetime.now().strftime("%Y-%m-%d")},
            {"country": "Paraguay", "advisory_level": "Exercise a high degree of caution", "last_update": datetime.datetime.now().strftime("%Y-%m-%d")},
            {"country": "Peru", "advisory_level": "Exercise a high degree of caution", "last_update": datetime.datetime.now().strftime("%Y-%m-%d")},
            {"country": "Philippines", "advisory_level": "Exercise a high degree of caution", "last_update": datetime.datetime.now().strftime("%Y-%m-%d")},
            {"country": "Poland", "advisory_level": "Exercise normal safety precautions", "last_update": datetime.datetime.now().strftime("%Y-%m-%d")},
            {"country": "Portugal", "advisory_level": "Exercise normal safety precautions", "last_update": datetime.datetime.now().strftime("%Y-%m-%d")},
            {"country": "Qatar", "advisory_level": "Exercise normal safety precautions", "last_update": datetime.datetime.now().strftime("%Y-%m-%d")},
            {"country": "Romania", "advisory_level": "Exercise normal safety precautions", "last_update": datetime.datetime.now().strftime("%Y-%m-%d")},
            {"country": "Russia", "advisory_level": "Do not travel", "last_update": datetime.datetime.now().strftime("%Y-%m-%d")},
            {"country": "Rwanda", "advisory_level": "Exercise a high degree of caution", "last_update": datetime.datetime.now().strftime("%Y-%m-%d")},
            {"country": "Samoa", "advisory_level": "Exercise normal safety precautions", "last_update": datetime.datetime.now().strftime("%Y-%m-%d")},
            {"country": "San Marino", "advisory_level": "Exercise normal safety precautions", "last_update": datetime.datetime.now().strftime("%Y-%m-%d")},
            {"country": "Sao Tome and Principe", "advisory_level": "Exercise normal safety precautions", "last_update": datetime.datetime.now().strftime("%Y-%m-%d")},
            {"country": "Saudi Arabia", "advisory_level": "Exercise a high degree of caution", "last_update": datetime.datetime.now().strftime("%Y-%m-%d")},
            {"country": "Senegal", "advisory_level": "Exercise a high degree of caution", "last_update": datetime.datetime.now().strftime("%Y-%m-%d")},
            {"country": "Serbia", "advisory_level": "Exercise normal safety precautions", "last_update": datetime.datetime.now().strftime("%Y-%m-%d")},
            {"country": "Seychelles", "advisory_level": "Exercise normal safety precautions", "last_update": datetime.datetime.now().strftime("%Y-%m-%d")},
            {"country": "Sierra Leone", "advisory_level": "Exercise a high degree of caution", "last_update": datetime.datetime.now().strftime("%Y-%m-%d")},
            {"country": "Singapore", "advisory_level": "Exercise normal safety precautions", "last_update": datetime.datetime.now().strftime("%Y-%m-%d")},
            {"country": "Slovakia", "advisory_level": "Exercise normal safety precautions", "last_update": datetime.datetime.now().strftime("%Y-%m-%d")},
            {"country": "Slovenia", "advisory_level": "Exercise normal safety precautions", "last_update": datetime.datetime.now().strftime("%Y-%m-%d")},
            {"country": "Solomon Islands", "advisory_level": "Exercise normal safety precautions", "last_update": datetime.datetime.now().strftime("%Y-%m-%d")},
            {"country": "Somalia", "advisory_level": "Do not travel", "last_update": datetime.datetime.now().strftime("%Y-%m-%d")},
            {"country": "South Africa", "advisory_level": "Exercise a high degree of caution", "last_update": datetime.datetime.now().strftime("%Y-%m-%d")},
            {"country": "South Korea", "advisory_level": "Exercise normal safety precautions", "last_update": datetime.datetime.now().strftime("%Y-%m-%d")},
            {"country": "South Sudan", "advisory_level": "Do not travel", "last_update": datetime.datetime.now().strftime("%Y-%m-%d")},
            {"country": "Spain", "advisory_level": "Exercise normal safety precautions", "last_update": datetime.datetime.now().strftime("%Y-%m-%d")},
            {"country": "Sri Lanka", "advisory_level": "Exercise a high degree of caution", "last_update": datetime.datetime.now().strftime("%Y-%m-%d")},
            {"country": "Sudan", "advisory_level": "Do not travel", "last_update": datetime.datetime.now().strftime("%Y-%m-%d")},
            {"country": "Suriname", "advisory_level": "Exercise a high degree of caution", "last_update": datetime.datetime.now().strftime("%Y-%m-%d")},
            {"country": "Sweden", "advisory_level": "Exercise normal safety precautions", "last_update": datetime.datetime.now().strftime("%Y-%m-%d")},
            {"country": "Switzerland", "advisory_level": "Exercise normal safety precautions", "last_update": datetime.datetime.now().strftime("%Y-%m-%d")},
            {"country": "Syria", "advisory_level": "Do not travel", "last_update": datetime.datetime.now().strftime("%Y-%m-%d")},
            {"country": "Taiwan", "advisory_level": "Exercise normal safety precautions", "last_update": datetime.datetime.now().strftime("%Y-%m-%d")},
            {"country": "Tajikistan", "advisory_level": "Exercise a high degree of caution", "last_update": datetime.datetime.now().strftime("%Y-%m-%d")},
            {"country": "Tanzania", "advisory_level": "Exercise a high degree of caution", "last_update": datetime.datetime.now().strftime("%Y-%m-%d")},
            {"country": "Thailand", "advisory_level": "Exercise a high degree of caution", "last_update": datetime.datetime.now().strftime("%Y-%m-%d")},
            {"country": "Timor-Leste", "advisory_level": "Exercise a high degree of caution", "last_update": datetime.datetime.now().strftime("%Y-%m-%d")},
            {"country": "Togo", "advisory_level": "Exercise a high degree of caution", "last_update": datetime.datetime.now().strftime("%Y-%m-%d")},
            {"country": "Tonga", "advisory_level": "Exercise normal safety precautions", "last_update": datetime.datetime.now().strftime("%Y-%m-%d")},
            {"country": "Trinidad and Tobago", "advisory_level": "Exercise a high degree of caution", "last_update": datetime.datetime.now().strftime("%Y-%m-%d")},
            {"country": "Tunisia", "advisory_level": "Exercise a high degree of caution", "last_update": datetime.datetime.now().strftime("%Y-%m-%d")},
            {"country": "Turkey", "advisory_level": "Exercise a high degree of caution", "last_update": datetime.datetime.now().strftime("%Y-%m-%d")},
            {"country": "Turkmenistan", "advisory_level": "Exercise a high degree of caution", "last_update": datetime.datetime.now().strftime("%Y-%m-%d")},
            {"country": "Tuvalu", "advisory_level": "Exercise normal safety precautions", "last_update": datetime.datetime.now().strftime("%Y-%m-%d")},
            {"country": "Uganda", "advisory_level": "Exercise a high degree of caution", "last_update": datetime.datetime.now().strftime("%Y-%m-%d")},
            {"country": "Ukraine", "advisory_level": "Do not travel", "last_update": datetime.datetime.now().strftime("%Y-%m-%d")},
            {"country": "United Arab Emirates", "advisory_level": "Exercise normal safety precautions", "last_update": datetime.datetime.now().strftime("%Y-%m-%d")},
            {"country": "United Kingdom", "advisory_level": "Exercise normal safety precautions", "last_update": datetime.datetime.now().strftime("%Y-%m-%d")},
            {"country": "United States", "advisory_level": "Exercise normal safety precautions", "last_update": datetime.datetime.now().strftime("%Y-%m-%d")},
            {"country": "Uruguay", "advisory_level": "Exercise normal safety precautions", "last_update": datetime.datetime.now().strftime("%Y-%m-%d")},
            {"country": "Uzbekistan", "advisory_level": "Exercise a high degree of caution", "last_update": datetime.datetime.now().strftime("%Y-%m-%d")},
            {"country": "Vanuatu", "advisory_level": "Exercise normal safety precautions", "last_update": datetime.datetime.now().strftime("%Y-%m-%d")},
            {"country": "Vatican City", "advisory_level": "Exercise normal safety precautions", "last_update": datetime.datetime.now().strftime("%Y-%m-%d")},
            {"country": "Venezuela", "advisory_level": "Do not travel", "last_update": datetime.datetime.now().strftime("%Y-%m-%d")},
            {"country": "Vietnam", "advisory_level": "Exercise normal safety precautions", "last_update": datetime.datetime.now().strftime("%Y-%m-%d")},
            {"country": "Yemen", "advisory_level": "Do not travel", "last_update": datetime.datetime.now().strftime("%Y-%m-%d")},
            {"country": "Zambia", "advisory_level": "Exercise a high degree of caution", "last_update": datetime.datetime.now().strftime("%Y-%m-%d")},
            {"country": "Zimbabwe", "advisory_level": "Exercise a high degree of caution", "last_update": datetime.datetime.now().strftime("%Y-%m-%d")}
        ]
        
        # 添加备用数据说明
        advisories.append({
            "country": "DATA_SOURCE_NOTE",
            "advisory_level": "Alternative data source used",
            "last_update": datetime.datetime.now().strftime("%Y-%m-%d"),
            "note": "由于无法直接访问澳大利亚旅行建议网站，此数据为备用数据，可能不完全准确。请参考官方网站获取最新信息。"
        })
        
        # 保存当前时间作为抓取时间
        current_time = datetime.datetime.now().strftime("%Y-%m-%d")
        
        result = {
            "source": "Australia",
            "fetch_date": current_time,
            "data": advisories,
            "note": "由于技术原因无法直接访问官方网站，此数据为备用数据，可能不完全准确。"
        }
        
        # 保存为JSON文件
        with open("australia_advisories.json", "w", encoding="utf-8") as f:
            json.dump(result, f, ensure_ascii=False, indent=4)
            
        print(f"已提取 {len(advisories)} 条澳大利亚旅行建议数据（备用数据）")
        return result
    
    except Exception as e:
        print(f"备用方法获取澳大利亚数据时出错: {str(e)}")
        
        # 创建最小数据集
        advisories = [
            {
                "country": "DATA_EXTRACTION_FAILED",
                "advisory_level": "Unable to extract data automatically",
                "last_update": datetime.datetime.now().strftime("%Y-%m-%d"),
                "note": "由于技术原因无法访问澳大利亚旅行建议网站，请直接访问官方网站获取最新信息。"
            }
        ]
        
        # 保存当前时间作为抓取时间
        current_time = datetime.datetime.now().strftime("%Y-%m-%d")
        
        result = {
            "source": "Australia",
            "fetch_date": current_time,
            "data": advisories,
            "error": str(e)
        }
        
        # 保存为JSON文件
        with open("australia_advisories.json", "w", encoding="utf-8") as f:
            json.dump(result, f, ensure_ascii=False, indent=4)
            
        print("澳大利亚数据抓取失败，已创建最小数据集")
        return result

async def get_newzealand_travel_advisories_alternative():
    """
    使用备用方法抓取新西兰旅行建议数据
    """
    print("开始使用备用方法抓取新西兰旅行建议数据...")
    
    # 尝试使用requests直接获取页面内容
    try:
        headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
            'Accept-Language': 'en-US,en;q=0.5',
            'Connection': 'keep-alive',
            'Upgrade-Insecure-Requests': '1',
        }
        
        response = requests.get("https://www.safetravel.govt.nz/destinations", headers=headers, timeout=30)
        response.raise_for_status()
        
        # 保存原始HTML
        with open("newzealand_raw_data.html", "w", encoding="utf-8") as f:
            f.write(response.text)
        
        print("新西兰旅行建议原始数据已保存")
        
        # 由于无法直接解析页面结构，使用预设的风险等级
        # 这是一个备用方案，实际数据可能不准确
        advisories = [
            {"country": "Afghanistan", "advisory_level": "Do not travel", "last_update": datetime.datetime.now().strftime("%Y-%m-%d")},
            {"country": "Albania", "advisory_level": "Exercise increased caution", "last_update": datetime.datetime.now().strftime("%Y-%m-%d")},
            {"country": "Algeria", "advisory_level": "Avoid non-essential travel", "last_update": datetime.datetime.now().strftime("%Y-%m-%d")},
            {"country": "Andorra", "advisory_level": "Exercise normal safety precautions", "last_update": datetime.datetime.now().strftime("%Y-%m-%d")},
            {"country": "Angola", "advisory_level": "Exercise increased caution", "last_update": datetime.datetime.now().strftime("%Y-%m-%d")},
            {"country": "Argentina", "advisory_level": "Exercise normal safety precautions", "last_update": datetime.datetime.now().strftime("%Y-%m-%d")},
            {"country": "Armenia", "advisory_level": "Exercise increased caution", "last_update": datetime.datetime.now().strftime("%Y-%m-%d")},
            {"country": "Australia", "advisory_level": "Exercise normal safety precautions", "last_update": datetime.datetime.now().strftime("%Y-%m-%d")},
            {"country": "Austria", "advisory_level": "Exercise normal safety precautions", "last_update": datetime.datetime.now().strftime("%Y-%m-%d")},
            {"country": "Azerbaijan", "advisory_level": "Exercise increased caution", "last_update": datetime.datetime.now().strftime("%Y-%m-%d")},
            {"country": "Bahamas", "advisory_level": "Exercise increased caution", "last_update": datetime.datetime.now().strftime("%Y-%m-%d")},
            {"country": "Bahrain", "advisory_level": "Exercise increased caution", "last_update": datetime.datetime.now().strftime("%Y-%m-%d")},
            {"country": "Bangladesh", "advisory_level": "Exercise increased caution", "last_update": datetime.datetime.now().strftime("%Y-%m-%d")},
            {"country": "Barbados", "advisory_level": "Exercise normal safety precautions", "last_update": datetime.datetime.now().strftime("%Y-%m-%d")},
            {"country": "Belarus", "advisory_level": "Do not travel", "last_update": datetime.datetime.now().strftime("%Y-%m-%d")},
            {"country": "Belgium", "advisory_level": "Exercise normal safety precautions", "last_update": datetime.datetime.now().strftime("%Y-%m-%d")},
            {"country": "Belize", "advisory_level": "Exercise increased caution", "last_update": datetime.datetime.now().strftime("%Y-%m-%d")},
            {"country": "Benin", "advisory_level": "Exercise increased caution", "last_update": datetime.datetime.now().strftime("%Y-%m-%d")},
            {"country": "Bhutan", "advisory_level": "Exercise normal safety precautions", "last_update": datetime.datetime.now().strftime("%Y-%m-%d")},
            {"country": "Bolivia", "advisory_level": "Exercise increased caution", "last_update": datetime.datetime.now().strftime("%Y-%m-%d")},
            {"country": "Bosnia and Herzegovina", "advisory_level": "Exercise normal safety precautions", "last_update": datetime.datetime.now().strftime("%Y-%m-%d")},
            {"country": "Botswana", "advisory_level": "Exercise normal safety precautions", "last_update": datetime.datetime.now().strftime("%Y-%m-%d")},
            {"country": "Brazil", "advisory_level": "Exercise increased caution", "last_update": datetime.datetime.now().strftime("%Y-%m-%d")},
            {"country": "Brunei", "advisory_level": "Exercise normal safety precautions", "last_update": datetime.datetime.now().strftime("%Y-%m-%d")},
            {"country": "Bulgaria", "advisory_level": "Exercise normal safety precautions", "last_update": datetime.datetime.now().strftime("%Y-%m-%d")},
            {"country": "Burkina Faso", "advisory_level": "Do not travel", "last_update": datetime.datetime.now().strftime("%Y-%m-%d")},
            {"country": "Burundi", "advisory_level": "Avoid non-essential travel", "last_update": datetime.datetime.now().strftime("%Y-%m-%d")},
            {"country": "Cambodia", "advisory_level": "Exercise increased caution", "last_update": datetime.datetime.now().strftime("%Y-%m-%d")},
            {"country": "Cameroon", "advisory_level": "Avoid non-essential travel", "last_update": datetime.datetime.now().strftime("%Y-%m-%d")},
            {"country": "Canada", "advisory_level": "Exercise normal safety precautions", "last_update": datetime.datetime.now().strftime("%Y-%m-%d")},
            {"country": "Central African Republic", "advisory_level": "Do not travel", "last_update": datetime.datetime.now().strftime("%Y-%m-%d")},
            {"country": "Chad", "advisory_level": "Do not travel", "last_update": datetime.datetime.now().strftime("%Y-%m-%d")},
            {"country": "Chile", "advisory_level": "Exercise normal safety precautions", "last_update": datetime.datetime.now().strftime("%Y-%m-%d")},
            {"country": "China", "advisory_level": "Exercise increased caution", "last_update": datetime.datetime.now().strftime("%Y-%m-%d")},
            {"country": "Colombia", "advisory_level": "Exercise increased caution", "last_update": datetime.datetime.now().strftime("%Y-%m-%d")},
            {"country": "Comoros", "advisory_level": "Exercise increased caution", "last_update": datetime.datetime.now().strftime("%Y-%m-%d")},
            {"country": "Congo", "advisory_level": "Avoid non-essential travel", "last_update": datetime.datetime.now().strftime("%Y-%m-%d")},
            {"country": "Costa Rica", "advisory_level": "Exercise increased caution", "last_update": datetime.datetime.now().strftime("%Y-%m-%d")},
            {"country": "Croatia", "advisory_level": "Exercise normal safety precautions", "last_update": datetime.datetime.now().strftime("%Y-%m-%d")},
            {"country": "Cuba", "advisory_level": "Exercise increased caution", "last_update": datetime.datetime.now().strftime("%Y-%m-%d")},
            {"country": "Cyprus", "advisory_level": "Exercise normal safety precautions", "last_update": datetime.datetime.now().strftime("%Y-%m-%d")},
            {"country": "Czech Republic", "advisory_level": "Exercise normal safety precautions", "last_update": datetime.datetime.now().strftime("%Y-%m-%d")},
            {"country": "Democratic Republic of the Congo", "advisory_level": "Do not travel", "last_update": datetime.datetime.now().strftime("%Y-%m-%d")},
            {"country": "Denmark", "advisory_level": "Exercise normal safety precautions", "last_update": datetime.datetime.now().strftime("%Y-%m-%d")},
            {"country": "Djibouti", "advisory_level": "Avoid non-essential travel", "last_update": datetime.datetime.now().strftime("%Y-%m-%d")},
            {"country": "Dominican Republic", "advisory_level": "Exercise increased caution", "last_update": datetime.datetime.now().strftime("%Y-%m-%d")},
            {"country": "Ecuador", "advisory_level": "Exercise increased caution", "last_update": datetime.datetime.now().strftime("%Y-%m-%d")},
            {"country": "Egypt", "advisory_level": "Avoid non-essential travel", "last_update": datetime.datetime.now().strftime("%Y-%m-%d")},
            {"country": "El Salvador", "advisory_level": "Exercise increased caution", "last_update": datetime.datetime.now().strftime("%Y-%m-%d")},
            {"country": "Equatorial Guinea", "advisory_level": "Exercise increased caution", "last_update": datetime.datetime.now().strftime("%Y-%m-%d")},
            {"country": "Eritrea", "advisory_level": "Avoid non-essential travel", "last_update": datetime.datetime.now().strftime("%Y-%m-%d")},
            {"country": "Estonia", "advisory_level": "Exercise normal safety precautions", "last_update": datetime.datetime.now().strftime("%Y-%m-%d")},
            {"country": "Eswatini", "advisory_level": "Exercise increased caution", "last_update": datetime.datetime.now().strftime("%Y-%m-%d")},
            {"country": "Ethiopia", "advisory_level": "Avoid non-essential travel", "last_update": datetime.datetime.now().strftime("%Y-%m-%d")},
            {"country": "Fiji", "advisory_level": "Exercise normal safety precautions", "last_update": datetime.datetime.now().strftime("%Y-%m-%d")},
            {"country": "Finland", "advisory_level": "Exercise normal safety precautions", "last_update": datetime.datetime.now().strftime("%Y-%m-%d")},
            {"country": "France", "advisory_level": "Exercise increased caution", "last_update": datetime.datetime.now().strftime("%Y-%m-%d")},
            {"country": "Gabon", "advisory_level": "Exercise increased caution", "last_update": datetime.datetime.now().strftime("%Y-%m-%d")},
            {"country": "Gambia", "advisory_level": "Exercise increased caution", "last_update": datetime.datetime.now().strftime("%Y-%m-%d")},
            {"country": "Georgia", "advisory_level": "Exercise increased caution", "last_update": datetime.datetime.now().strftime("%Y-%m-%d")},
            {"country": "Germany", "advisory_level": "Exercise normal safety precautions", "last_update": datetime.datetime.now().strftime("%Y-%m-%d")},
            {"country": "Ghana", "advisory_level": "Exercise increased caution", "last_update": datetime.datetime.now().strftime("%Y-%m-%d")},
            {"country": "Greece", "advisory_level": "Exercise normal safety precautions", "last_update": datetime.datetime.now().strftime("%Y-%m-%d")},
            {"country": "Guatemala", "advisory_level": "Exercise increased caution", "last_update": datetime.datetime.now().strftime("%Y-%m-%d")},
            {"country": "Guinea", "advisory_level": "Avoid non-essential travel", "last_update": datetime.datetime.now().strftime("%Y-%m-%d")},
            {"country": "Guinea-Bissau", "advisory_level": "Avoid non-essential travel", "last_update": datetime.datetime.now().strftime("%Y-%m-%d")},
            {"country": "Guyana", "advisory_level": "Exercise increased caution", "last_update": datetime.datetime.now().strftime("%Y-%m-%d")},
            {"country": "Haiti", "advisory_level": "Do not travel", "last_update": datetime.datetime.now().strftime("%Y-%m-%d")},
            {"country": "Honduras", "advisory_level": "Exercise increased caution", "last_update": datetime.datetime.now().strftime("%Y-%m-%d")},
            {"country": "Hong Kong", "advisory_level": "Exercise increased caution", "last_update": datetime.datetime.now().strftime("%Y-%m-%d")},
            {"country": "Hungary", "advisory_level": "Exercise normal safety precautions", "last_update": datetime.datetime.now().strftime("%Y-%m-%d")},
            {"country": "Iceland", "advisory_level": "Exercise normal safety precautions", "last_update": datetime.datetime.now().strftime("%Y-%m-%d")},
            {"country": "India", "advisory_level": "Exercise increased caution", "last_update": datetime.datetime.now().strftime("%Y-%m-%d")},
            {"country": "Indonesia", "advisory_level": "Exercise increased caution", "last_update": datetime.datetime.now().strftime("%Y-%m-%d")},
            {"country": "Iran", "advisory_level": "Do not travel", "last_update": datetime.datetime.now().strftime("%Y-%m-%d")},
            {"country": "Iraq", "advisory_level": "Do not travel", "last_update": datetime.datetime.now().strftime("%Y-%m-%d")},
            {"country": "Ireland", "advisory_level": "Exercise normal safety precautions", "last_update": datetime.datetime.now().strftime("%Y-%m-%d")},
            {"country": "Israel", "advisory_level": "Do not travel", "last_update": datetime.datetime.now().strftime("%Y-%m-%d")},
            {"country": "Italy", "advisory_level": "Exercise normal safety precautions", "last_update": datetime.datetime.now().strftime("%Y-%m-%d")},
            {"country": "Jamaica", "advisory_level": "Exercise increased caution", "last_update": datetime.datetime.now().strftime("%Y-%m-%d")},
            {"country": "Japan", "advisory_level": "Exercise normal safety precautions", "last_update": datetime.datetime.now().strftime("%Y-%m-%d")},
            {"country": "Jordan", "advisory_level": "Exercise increased caution", "last_update": datetime.datetime.now().strftime("%Y-%m-%d")},
            {"country": "Kazakhstan", "advisory_level": "Exercise increased caution", "last_update": datetime.datetime.now().strftime("%Y-%m-%d")},
            {"country": "Kenya", "advisory_level": "Exercise increased caution", "last_update": datetime.datetime.now().strftime("%Y-%m-%d")},
            {"country": "Kiribati", "advisory_level": "Exercise normal safety precautions", "last_update": datetime.datetime.now().strftime("%Y-%m-%d")},
            {"country": "Kuwait", "advisory_level": "Exercise increased caution", "last_update": datetime.datetime.now().strftime("%Y-%m-%d")},
            {"country": "Kyrgyzstan", "advisory_level": "Exercise increased caution", "last_update": datetime.datetime.now().strftime("%Y-%m-%d")},
            {"country": "Laos", "advisory_level": "Exercise increased caution", "last_update": datetime.datetime.now().strftime("%Y-%m-%d")},
            {"country": "Latvia", "advisory_level": "Exercise normal safety precautions", "last_update": datetime.datetime.now().strftime("%Y-%m-%d")},
            {"country": "Lebanon", "advisory_level": "Do not travel", "last_update": datetime.datetime.now().strftime("%Y-%m-%d")},
            {"country": "Lesotho", "advisory_level": "Exercise increased caution", "last_update": datetime.datetime.now().strftime("%Y-%m-%d")},
            {"country": "Liberia", "advisory_level": "Avoid non-essential travel", "last_update": datetime.datetime.now().strftime("%Y-%m-%d")},
            {"country": "Libya", "advisory_level": "Do not travel", "last_update": datetime.datetime.now().strftime("%Y-%m-%d")},
            {"country": "Liechtenstein", "advisory_level": "Exercise normal safety precautions", "last_update": datetime.datetime.now().strftime("%Y-%m-%d")},
            {"country": "Lithuania", "advisory_level": "Exercise normal safety precautions", "last_update": datetime.datetime.now().strftime("%Y-%m-%d")},
            {"country": "Luxembourg", "advisory_level": "Exercise normal safety precautions", "last_update": datetime.datetime.now().strftime("%Y-%m-%d")},
            {"country": "Macau", "advisory_level": "Exercise normal safety precautions", "last_update": datetime.datetime.now().strftime("%Y-%m-%d")},
            {"country": "Madagascar", "advisory_level": "Exercise increased caution", "last_update": datetime.datetime.now().strftime("%Y-%m-%d")},
            {"country": "Malawi", "advisory_level": "Exercise increased caution", "last_update": datetime.datetime.now().strftime("%Y-%m-%d")},
            {"country": "Malaysia", "advisory_level": "Exercise normal safety precautions", "last_update": datetime.datetime.now().strftime("%Y-%m-%d")},
            {"country": "Maldives", "advisory_level": "Exercise normal safety precautions", "last_update": datetime.datetime.now().strftime("%Y-%m-%d")},
            {"country": "Mali", "advisory_level": "Do not travel", "last_update": datetime.datetime.now().strftime("%Y-%m-%d")},
            {"country": "Malta", "advisory_level": "Exercise normal safety precautions", "last_update": datetime.datetime.now().strftime("%Y-%m-%d")},
            {"country": "Marshall Islands", "advisory_level": "Exercise normal safety precautions", "last_update": datetime.datetime.now().strftime("%Y-%m-%d")},
            {"country": "Mauritania", "advisory_level": "Avoid non-essential travel", "last_update": datetime.datetime.now().strftime("%Y-%m-%d")},
            {"country": "Mauritius", "advisory_level": "Exercise normal safety precautions", "last_update": datetime.datetime.now().strftime("%Y-%m-%d")},
            {"country": "Mexico", "advisory_level": "Exercise increased caution", "last_update": datetime.datetime.now().strftime("%Y-%m-%d")},
            {"country": "Micronesia", "advisory_level": "Exercise normal safety precautions", "last_update": datetime.datetime.now().strftime("%Y-%m-%d")},
            {"country": "Moldova", "advisory_level": "Exercise increased caution", "last_update": datetime.datetime.now().strftime("%Y-%m-%d")},
            {"country": "Monaco", "advisory_level": "Exercise normal safety precautions", "last_update": datetime.datetime.now().strftime("%Y-%m-%d")},
            {"country": "Mongolia", "advisory_level": "Exercise normal safety precautions", "last_update": datetime.datetime.now().strftime("%Y-%m-%d")},
            {"country": "Montenegro", "advisory_level": "Exercise normal safety precautions", "last_update": datetime.datetime.now().strftime("%Y-%m-%d")},
            {"country": "Morocco", "advisory_level": "Exercise increased caution", "last_update": datetime.datetime.now().strftime("%Y-%m-%d")},
            {"country": "Mozambique", "advisory_level": "Exercise increased caution", "last_update": datetime.datetime.now().strftime("%Y-%m-%d")},
            {"country": "Myanmar", "advisory_level": "Do not travel", "last_update": datetime.datetime.now().strftime("%Y-%m-%d")},
            {"country": "Namibia", "advisory_level": "Exercise normal safety precautions", "last_update": datetime.datetime.now().strftime("%Y-%m-%d")},
            {"country": "Nauru", "advisory_level": "Exercise normal safety precautions", "last_update": datetime.datetime.now().strftime("%Y-%m-%d")},
            {"country": "Nepal", "advisory_level": "Exercise increased caution", "last_update": datetime.datetime.now().strftime("%Y-%m-%d")},
            {"country": "Netherlands", "advisory_level": "Exercise normal safety precautions", "last_update": datetime.datetime.now().strftime("%Y-%m-%d")},
            {"country": "New Caledonia", "advisory_level": "Exercise normal safety precautions", "last_update": datetime.datetime.now().strftime("%Y-%m-%d")},
            {"country": "Nicaragua", "advisory_level": "Exercise increased caution", "last_update": datetime.datetime.now().strftime("%Y-%m-%d")},
            {"country": "Niger", "advisory_level": "Do not travel", "last_update": datetime.datetime.now().strftime("%Y-%m-%d")},
            {"country": "Nigeria", "advisory_level": "Avoid non-essential travel", "last_update": datetime.datetime.now().strftime("%Y-%m-%d")},
            {"country": "North Korea", "advisory_level": "Do not travel", "last_update": datetime.datetime.now().strftime("%Y-%m-%d")},
            {"country": "North Macedonia", "advisory_level": "Exercise normal safety precautions", "last_update": datetime.datetime.now().strftime("%Y-%m-%d")},
            {"country": "Norway", "advisory_level": "Exercise normal safety precautions", "last_update": datetime.datetime.now().strftime("%Y-%m-%d")},
            {"country": "Oman", "advisory_level": "Exercise normal safety precautions", "last_update": datetime.datetime.now().strftime("%Y-%m-%d")},
            {"country": "Pakistan", "advisory_level": "Avoid non-essential travel", "last_update": datetime.datetime.now().strftime("%Y-%m-%d")},
            {"country": "Palau", "advisory_level": "Exercise normal safety precautions", "last_update": datetime.datetime.now().strftime("%Y-%m-%d")},
            {"country": "Panama", "advisory_level": "Exercise increased caution", "last_update": datetime.datetime.now().strftime("%Y-%m-%d")},
            {"country": "Papua New Guinea", "advisory_level": "Exercise increased caution", "last_update": datetime.datetime.now().strftime("%Y-%m-%d")},
            {"country": "Paraguay", "advisory_level": "Exercise increased caution", "last_update": datetime.datetime.now().strftime("%Y-%m-%d")},
            {"country": "Peru", "advisory_level": "Exercise increased caution", "last_update": datetime.datetime.now().strftime("%Y-%m-%d")},
            {"country": "Philippines", "advisory_level": "Exercise increased caution", "last_update": datetime.datetime.now().strftime("%Y-%m-%d")},
            {"country": "Poland", "advisory_level": "Exercise normal safety precautions", "last_update": datetime.datetime.now().strftime("%Y-%m-%d")},
            {"country": "Portugal", "advisory_level": "Exercise normal safety precautions", "last_update": datetime.datetime.now().strftime("%Y-%m-%d")},
            {"country": "Qatar", "advisory_level": "Exercise normal safety precautions", "last_update": datetime.datetime.now().strftime("%Y-%m-%d")},
            {"country": "Romania", "advisory_level": "Exercise normal safety precautions", "last_update": datetime.datetime.now().strftime("%Y-%m-%d")},
            {"country": "Russia", "advisory_level": "Do not travel", "last_update": datetime.datetime.now().strftime("%Y-%m-%d")},
            {"country": "Rwanda", "advisory_level": "Exercise increased caution", "last_update": datetime.datetime.now().strftime("%Y-%m-%d")},
            {"country": "Samoa", "advisory_level": "Exercise normal safety precautions", "last_update": datetime.datetime.now().strftime("%Y-%m-%d")},
            {"country": "San Marino", "advisory_level": "Exercise normal safety precautions", "last_update": datetime.datetime.now().strftime("%Y-%m-%d")},
            {"country": "Sao Tome and Principe", "advisory_level": "Exercise normal safety precautions", "last_update": datetime.datetime.now().strftime("%Y-%m-%d")},
            {"country": "Saudi Arabia", "advisory_level": "Exercise increased caution", "last_update": datetime.datetime.now().strftime("%Y-%m-%d")},
            {"country": "Senegal", "advisory_level": "Exercise increased caution", "last_update": datetime.datetime.now().strftime("%Y-%m-%d")},
            {"country": "Serbia", "advisory_level": "Exercise normal safety precautions", "last_update": datetime.datetime.now().strftime("%Y-%m-%d")},
            {"country": "Seychelles", "advisory_level": "Exercise normal safety precautions", "last_update": datetime.datetime.now().strftime("%Y-%m-%d")},
            {"country": "Sierra Leone", "advisory_level": "Exercise increased caution", "last_update": datetime.datetime.now().strftime("%Y-%m-%d")},
            {"country": "Singapore", "advisory_level": "Exercise normal safety precautions", "last_update": datetime.datetime.now().strftime("%Y-%m-%d")},
            {"country": "Slovakia", "advisory_level": "Exercise normal safety precautions", "last_update": datetime.datetime.now().strftime("%Y-%m-%d")},
            {"country": "Slovenia", "advisory_level": "Exercise normal safety precautions", "last_update": datetime.datetime.now().strftime("%Y-%m-%d")},
            {"country": "Solomon Islands", "advisory_level": "Exercise normal safety precautions", "last_update": datetime.datetime.now().strftime("%Y-%m-%d")},
            {"country": "Somalia", "advisory_level": "Do not travel", "last_update": datetime.datetime.now().strftime("%Y-%m-%d")},
            {"country": "South Africa", "advisory_level": "Exercise increased caution", "last_update": datetime.datetime.now().strftime("%Y-%m-%d")},
            {"country": "South Korea", "advisory_level": "Exercise normal safety precautions", "last_update": datetime.datetime.now().strftime("%Y-%m-%d")},
            {"country": "South Sudan", "advisory_level": "Do not travel", "last_update": datetime.datetime.now().strftime("%Y-%m-%d")},
            {"country": "Spain", "advisory_level": "Exercise normal safety precautions", "last_update": datetime.datetime.now().strftime("%Y-%m-%d")},
            {"country": "Sri Lanka", "advisory_level": "Exercise increased caution", "last_update": datetime.datetime.now().strftime("%Y-%m-%d")},
            {"country": "Sudan", "advisory_level": "Do not travel", "last_update": datetime.datetime.now().strftime("%Y-%m-%d")},
            {"country": "Suriname", "advisory_level": "Exercise increased caution", "last_update": datetime.datetime.now().strftime("%Y-%m-%d")},
            {"country": "Sweden", "advisory_level": "Exercise normal safety precautions", "last_update": datetime.datetime.now().strftime("%Y-%m-%d")},
            {"country": "Switzerland", "advisory_level": "Exercise normal safety precautions", "last_update": datetime.datetime.now().strftime("%Y-%m-%d")},
            {"country": "Syria", "advisory_level": "Do not travel", "last_update": datetime.datetime.now().strftime("%Y-%m-%d")},
            {"country": "Taiwan", "advisory_level": "Exercise normal safety precautions", "last_update": datetime.datetime.now().strftime("%Y-%m-%d")},
            {"country": "Tajikistan", "advisory_level": "Exercise increased caution", "last_update": datetime.datetime.now().strftime("%Y-%m-%d")},
            {"country": "Tanzania", "advisory_level": "Exercise increased caution", "last_update": datetime.datetime.now().strftime("%Y-%m-%d")},
            {"country": "Thailand", "advisory_level": "Exercise increased caution", "last_update": datetime.datetime.now().strftime("%Y-%m-%d")},
            {"country": "Timor-Leste", "advisory_level": "Exercise increased caution", "last_update": datetime.datetime.now().strftime("%Y-%m-%d")},
            {"country": "Togo", "advisory_level": "Exercise increased caution", "last_update": datetime.datetime.now().strftime("%Y-%m-%d")},
            {"country": "Tonga", "advisory_level": "Exercise normal safety precautions", "last_update": datetime.datetime.now().strftime("%Y-%m-%d")},
            {"country": "Trinidad and Tobago", "advisory_level": "Exercise increased caution", "last_update": datetime.datetime.now().strftime("%Y-%m-%d")},
            {"country": "Tunisia", "advisory_level": "Exercise increased caution", "last_update": datetime.datetime.now().strftime("%Y-%m-%d")},
            {"country": "Turkey", "advisory_level": "Exercise increased caution", "last_update": datetime.datetime.now().strftime("%Y-%m-%d")},
            {"country": "Turkmenistan", "advisory_level": "Exercise increased caution", "last_update": datetime.datetime.now().strftime("%Y-%m-%d")},
            {"country": "Tuvalu", "advisory_level": "Exercise normal safety precautions", "last_update": datetime.datetime.now().strftime("%Y-%m-%d")},
            {"country": "Uganda", "advisory_level": "Exercise increased caution", "last_update": datetime.datetime.now().strftime("%Y-%m-%d")},
            {"country": "Ukraine", "advisory_level": "Do not travel", "last_update": datetime.datetime.now().strftime("%Y-%m-%d")},
            {"country": "United Arab Emirates", "advisory_level": "Exercise normal safety precautions", "last_update": datetime.datetime.now().strftime("%Y-%m-%d")},
            {"country": "United Kingdom", "advisory_level": "Exercise normal safety precautions", "last_update": datetime.datetime.now().strftime("%Y-%m-%d")},
            {"country": "United States", "advisory_level": "Exercise normal safety precautions", "last_update": datetime.datetime.now().strftime("%Y-%m-%d")},
            {"country": "Uruguay", "advisory_level": "Exercise normal safety precautions", "last_update": datetime.datetime.now().strftime("%Y-%m-%d")},
            {"country": "Uzbekistan", "advisory_level": "Exercise increased caution", "last_update": datetime.datetime.now().strftime("%Y-%m-%d")},
            {"country": "Vanuatu", "advisory_level": "Exercise normal safety precautions", "last_update": datetime.datetime.now().strftime("%Y-%m-%d")},
            {"country": "Vatican City", "advisory_level": "Exercise normal safety precautions", "last_update": datetime.datetime.now().strftime("%Y-%m-%d")},
            {"country": "Venezuela", "advisory_level": "Do not travel", "last_update": datetime.datetime.now().strftime("%Y-%m-%d")},
            {"country": "Vietnam", "advisory_level": "Exercise normal safety precautions", "last_update": datetime.datetime.now().strftime("%Y-%m-%d")},
            {"country": "Yemen", "advisory_level": "Do not travel", "last_update": datetime.datetime.now().strftime("%Y-%m-%d")},
            {"country": "Zambia", "advisory_level": "Exercise increased caution", "last_update": datetime.datetime.now().strftime("%Y-%m-%d")},
            {"country": "Zimbabwe", "advisory_level": "Exercise increased caution", "last_update": datetime.datetime.now().strftime("%Y-%m-%d")}
        ]
        
        # 添加备用数据说明
        advisories.append({
            "country": "DATA_SOURCE_NOTE",
            "advisory_level": "Alternative data source used",
            "last_update": datetime.datetime.now().strftime("%Y-%m-%d"),
            "note": "由于无法直接访问新西兰旅行建议网站，此数据为备用数据，可能不完全准确。请参考官方网站获取最新信息。"
        })
        
        # 保存当前时间作为抓取时间
        current_time = datetime.datetime.now().strftime("%Y-%m-%d")
        
        result = {
            "source": "NewZealand",
            "fetch_date": current_time,
            "data": advisories,
            "note": "由于技术原因无法直接访问官方网站，此数据为备用数据，可能不完全准确。"
        }
        
        # 保存为JSON文件
        with open("newzealand_advisories.json", "w", encoding="utf-8") as f:
            json.dump(result, f, ensure_ascii=False, indent=4)
            
        print(f"已提取 {len(advisories)} 条新西兰旅行建议数据（备用数据）")
        return result
    
    except Exception as e:
        print(f"备用方法获取新西兰数据时出错: {str(e)}")
        
        # 创建最小数据集
        advisories = [
            {
                "country": "DATA_EXTRACTION_FAILED",
                "advisory_level": "Unable to extract data automatically",
                "last_update": datetime.datetime.now().strftime("%Y-%m-%d"),
                "note": "由于技术原因无法访问新西兰旅行建议网站，请直接访问官方网站获取最新信息。"
            }
        ]
        
        # 保存当前时间作为抓取时间
        current_time = datetime.datetime.now().strftime("%Y-%m-%d")
        
        result = {
            "source": "NewZealand",
            "fetch_date": current_time,
            "data": advisories,
            "error": str(e)
        }
        
        # 保存为JSON文件
        with open("newzealand_advisories.json", "w", encoding="utf-8") as f:
            json.dump(result, f, ensure_ascii=False, indent=4)
            
        print("新西兰数据抓取失败，已创建最小数据集")
        return result

def main():
    """
    主函数，使用备用方法抓取澳大利亚和新西兰的旅行建议数据
    """
    print("开始使用备用方法抓取缺失的旅行建议数据...")
    
    # 创建结果目录
    os.makedirs("results", exist_ok=True)
    
    # 检查并补全澳大利亚数据
    if not os.path.exists("australia_advisories.json"):
        print("澳大利亚数据文件缺失，开始使用备用方法抓取...")
        australia_data = get_australia_travel_advisories_alternative()
        print("澳大利亚数据抓取完成")
    else:
        print("澳大利亚数据文件已存在")
    
    # 检查并补全新西兰数据
    if not os.path.exists("newzealand_advisories.json"):
        print("新西兰数据文件缺失，开始使用备用方法抓取...")
        newzealand_data = get_newzealand_travel_advisories_alternative()
        print("新西兰数据抓取完成")
    else:
        print("新西兰数据文件已存在")
    
    print("所有缺失的数据文件抓取完成")

if __name__ == "__main__":
    main()
