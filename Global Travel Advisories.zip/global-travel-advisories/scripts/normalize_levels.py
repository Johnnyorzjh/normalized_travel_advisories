import json
import os
import datetime

# 定义归一化标准
def define_normalization_standard():
    """
    定义各数据源风险等级的归一化标准
    
    归一化为四个等级：
    1 - 低风险：建议正常出行
    2 - 中等风险：建议提高警觉
    3 - 高风险：建议谨慎出行
    4 - 极高风险：建议避免出行
    """
    normalization_standard = {
        # 美国风险等级归一化标准
        "US": {
            "Level 1": 1,  # Exercise Normal Precautions
            "Level 2": 2,  # Exercise Increased Caution
            "Level 3": 3,  # Reconsider Travel
            "Level 4": 4,  # Do Not Travel
            # 其他可能的表述
            "Exercise Normal Precautions": 1,
            "Exercise Increased Caution": 2,
            "Reconsider Travel": 3,
            "Do Not Travel": 4
        },
        
        # 英国风险等级归一化标准
        "UK": {
            "See our travel advice": 1,  # 一般建议
            "Advise against all but essential travel": 3,  # 建议避免非必要旅行
            "Advise against all travel": 4,  # 建议避免所有旅行
            # 其他可能的表述
            "The Foreign, Commonwealth & Development Office (FCDO) advises against all travel": 4,
            "The Foreign, Commonwealth & Development Office (FCDO) advises against all but essential travel": 3,
            "See our travel advice before travelling": 1
        },
        
        # 加拿大风险等级归一化标准
        "Canada": {
            "Exercise normal security precautions": 1,
            "Exercise a high degree of caution": 2,
            "Avoid non-essential travel": 3,
            "Avoid all travel": 4,
            # 其他可能的表述
            "Normal security precautions": 1,
            "High degree of caution": 2,
            "Non-essential travel": 3,
            "All travel": 4
        },
        
        # 澳大利亚风险等级归一化标准
        "Australia": {
            "Exercise normal safety precautions": 1,
            "Exercise a high degree of caution": 2,
            "Reconsider your need to travel": 3,
            "Do not travel": 4,
            # 其他可能的表述
            "Normal safety precautions": 1,
            "High degree of caution": 2,
            "Reconsider your need": 3,
            "Do not": 4
        },
        
        # 新西兰风险等级归一化标准
        "NewZealand": {
            "Exercise normal safety precautions": 1,
            "Exercise increased caution": 2,
            "Avoid non-essential travel": 3,
            "Do not travel": 4,
            # 其他可能的表述
            "Normal safety precautions": 1,
            "Increased caution": 2,
            "Non-essential travel": 3,
            "Avoid all travel": 4
        }
    }
    
    # 添加通用关键词匹配规则，用于处理未明确定义的情况
    generic_rules = {
        "low": ["normal", "safe", "low risk", "no restriction", "no advisory", "exercise normal"],
        "medium": ["caution", "increased", "vigilant", "aware", "alert", "exercise caution", "high degree"],
        "high": ["reconsider", "avoid non", "essential", "necessary", "avoid unnecessary", "reconsidering"],
        "extreme": ["do not", "avoid all", "against all", "no travel", "not travel", "extreme"]
    }
    
    return normalization_standard, generic_rules

def normalize_advisory_level(source, level, normalization_standard, generic_rules):
    """
    根据归一化标准，将原始风险等级转换为标准等级
    
    参数:
    source - 数据源（US, UK, Canada, Australia, NewZealand）
    level - 原始风险等级文本
    
    返回:
    normalized_level - 归一化后的风险等级（1-4）
    normalized_text - 归一化后的风险等级文本描述
    """
    # 默认为中等风险
    normalized_level = 2
    
    # 如果level为空或不是字符串，返回默认值
    if not level or not isinstance(level, str):
        return normalized_level, get_normalized_text(normalized_level)
    
    # 尝试直接匹配
    if source in normalization_standard and level in normalization_standard[source]:
        normalized_level = normalization_standard[source][level]
        return normalized_level, get_normalized_text(normalized_level)
    
    # 尝试部分匹配
    level_lower = level.lower()
    for standard_level, value in normalization_standard.get(source, {}).items():
        if standard_level.lower() in level_lower:
            return value, get_normalized_text(value)
    
    # 使用通用规则进行匹配
    for risk_level, keywords in generic_rules.items():
        for keyword in keywords:
            if keyword.lower() in level_lower:
                if risk_level == "low":
                    return 1, get_normalized_text(1)
                elif risk_level == "medium":
                    return 2, get_normalized_text(2)
                elif risk_level == "high":
                    return 3, get_normalized_text(3)
                elif risk_level == "extreme":
                    return 4, get_normalized_text(4)
    
    # 如果无法匹配，返回默认值
    return normalized_level, get_normalized_text(normalized_level)

def get_normalized_text(level):
    """
    根据归一化等级返回对应的文本描述
    """
    if level == 1:
        return "低风险：建议正常出行"
    elif level == 2:
        return "中等风险：建议提高警觉"
    elif level == 3:
        return "高风险：建议谨慎出行"
    elif level == 4:
        return "极高风险：建议避免出行"
    else:
        return "未知风险级别"

def read_json_file(file_path):
    """
    读取JSON文件并返回数据
    """
    try:
        with open(file_path, 'r', encoding='utf-8') as f:
            data = json.load(f)
        return data
    except Exception as e:
        print(f"读取文件 {file_path} 时出错: {e}")
        return None

def normalize_data():
    """
    读取整合后的数据，添加归一化风险等级
    """
    print("开始添加归一化风险等级...")
    
    # 读取整合后的数据
    try:
        with open("results/new_integrated_travel_advisories.json", "r", encoding="utf-8") as f:
            data = json.load(f)
    except Exception as e:
        print(f"读取整合后的数据时出错: {e}")
        return False
    
    # 获取归一化标准
    normalization_standard, generic_rules = define_normalization_standard()
    
    # 添加归一化风险等级
    for country, country_data in data.items():
        for source, source_data in country_data.items():
            if isinstance(source_data, dict) and "advisory_level" in source_data:
                level = source_data["advisory_level"]
                normalized_level, normalized_text = normalize_advisory_level(
                    source, level, normalization_standard, generic_rules
                )
                source_data["normalized_level"] = normalized_level
                source_data["normalized_text"] = normalized_text
    
    # 保存添加了归一化风险等级的数据
    with open("results/normalized_travel_advisories.json", "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=4)
    
    print("归一化风险等级已添加，结果已保存到 results/normalized_travel_advisories.json")
    return data

def create_normalization_standard_doc():
    """
    创建归一化标准文档
    """
    print("创建归一化标准文档...")
    
    normalization_standard, generic_rules = define_normalization_standard()
    
    doc = """# 旅行风险等级归一化标准

## 归一化等级定义

我们将各数据源的风险等级归一化为以下四个标准等级：

1. **低风险：建议正常出行** - 目的地安全状况良好，可以正常旅行，注意基本安全即可。
2. **中等风险：建议提高警觉** - 目的地存在一定安全隐患，旅行时需提高警惕，注意个人安全。
3. **高风险：建议谨慎出行** - 目的地存在较高安全风险，建议重新考虑旅行计划，如必须前往应采取额外安全措施。
4. **极高风险：建议避免出行** - 目的地存在严重安全威胁，强烈建议避免前往。

## 各数据源风险等级映射关系

### 美国国务院旅行建议 (US)

| 原始风险等级 | 归一化等级 | 归一化描述 |
|------------|-----------|----------|
| Level 1 / Exercise Normal Precautions | 1 | 低风险：建议正常出行 |
| Level 2 / Exercise Increased Caution | 2 | 中等风险：建议提高警觉 |
| Level 3 / Reconsider Travel | 3 | 高风险：建议谨慎出行 |
| Level 4 / Do Not Travel | 4 | 极高风险：建议避免出行 |

### 英国外交、联邦和发展办公室旅行建议 (UK)

| 原始风险等级 | 归一化等级 | 归一化描述 |
|------------|-----------|----------|
| See our travel advice | 1 | 低风险：建议正常出行 |
| Advise against all but essential travel | 3 | 高风险：建议谨慎出行 |
| Advise against all travel | 4 | 极高风险：建议避免出行 |

### 加拿大旅行建议 (Canada)

| 原始风险等级 | 归一化等级 | 归一化描述 |
|------------|-----------|----------|
| Exercise normal security precautions | 1 | 低风险：建议正常出行 |
| Exercise a high degree of caution | 2 | 中等风险：建议提高警觉 |
| Avoid non-essential travel | 3 | 高风险：建议谨慎出行 |
| Avoid all travel | 4 | 极高风险：建议避免出行 |

### 澳大利亚旅行建议 (Australia)

| 原始风险等级 | 归一化等级 | 归一化描述 |
|------------|-----------|----------|
| Exercise normal safety precautions | 1 | 低风险：建议正常出行 |
| Exercise a high degree of caution | 2 | 中等风险：建议提高警觉 |
| Reconsider your need to travel | 3 | 高风险：建议谨慎出行 |
| Do not travel | 4 | 极高风险：建议避免出行 |

### 新西兰旅行建议 (NewZealand)

| 原始风险等级 | 归一化等级 | 归一化描述 |
|------------|-----------|----------|
| Exercise normal safety precautions | 1 | 低风险：建议正常出行 |
| Exercise increased caution | 2 | 中等风险：建议提高警觉 |
| Avoid non-essential travel | 3 | 高风险：建议谨慎出行 |
| Do not travel | 4 | 极高风险：建议避免出行 |

## 通用关键词匹配规则

对于未明确定义的风险等级表述，系统使用以下关键词进行匹配：

### 低风险关键词
"""
    
    # 添加通用规则
    for risk_level, keywords in generic_rules.items():
        if risk_level == "low":
            doc += ", ".join([f"`{keyword}`" for keyword in keywords]) + "\n\n"
            doc += "### 中等风险关键词\n"
        elif risk_level == "medium":
            doc += ", ".join([f"`{keyword}`" for keyword in keywords]) + "\n\n"
            doc += "### 高风险关键词\n"
        elif risk_level == "high":
            doc += ", ".join([f"`{keyword}`" for keyword in keywords]) + "\n\n"
            doc += "### 极高风险关键词\n"
        elif risk_level == "extreme":
            doc += ", ".join([f"`{keyword}`" for keyword in keywords]) + "\n\n"
    
    doc += """
## 数据结构说明

在JSON数据中，每个国家的每个数据源都添加了以下两个字段：

1. `normalized_level`: 归一化后的风险等级数值（1-4）
2. `normalized_text`: 归一化后的风险等级文本描述

示例：
```json
{
  "Afghanistan": {
    "US": {
      "advisory_level": "Level 4: Do Not Travel",
      "last_update": "2023-07-10",
      "source": "US",
      "normalized_level": 4,
      "normalized_text": "极高风险：建议避免出行"
    }
  }
}
```

## 注意事项

1. 由于各数据源使用不同的风险评估体系，归一化过程可能存在一定的主观判断
2. 对于无法明确匹配的风险等级，系统会使用通用关键词规则进行匹配
3. 如果仍无法匹配，将默认归类为"中等风险"
4. 建议同时参考原始风险等级和归一化风险等级进行决策
"""
    
    # 保存归一化标准文档
    with open("results/normalization_standard.md", "w", encoding="utf-8") as f:
        f.write(doc)
    
    print("归一化标准文档已保存到 results/normalization_standard.md")
    return True

def create_summary_report(data):
    """
    创建包含归一化风险等级的摘要报告
    """
    print("开始创建包含归一化风险等级的摘要报告...")
    
    # 统计信息
    total_countries = len(data)
    risk_level_counts = {1: 0, 2: 0, 3: 0, 4: 0}
    countries_by_risk = {1: [], 2: [], 3: [], 4: []}
    
    # 计算每个国家的平均风险等级
    for country, country_data in data.items():
        total_level = 0
        count = 0
        
        for source, source_data in country_data.items():
            if isinstance(source_data, dict) and "normalized_level" in source_data:
                total_level += source_data["normalized_level"]
                count += 1
        
        if count > 0:
            avg_level = round(total_level / count)
            risk_level_counts[avg_level] += 1
            countries_by_risk[avg_level].append(country)
    
    # 创建摘要报告
    report = {
        "report_date": datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        "data_sources": ["美国", "英国", "加拿大", "澳大利亚", "新西兰"],
        "total_countries": total_countries,
        "risk_level_counts": risk_level_counts,
        "high_risk_countries": countries_by_risk[4],
        "data_sample": {}
    }
    
    # 添加数据样本（每个风险等级选择一个国家）
    for level in [1, 2, 3, 4]:
        if countries_by_risk[level]:
            sample_country = countries_by_risk[level][0]
            report["data_sample"][sample_country] = data[sample_country]
    
    # 保存摘要报告
    with open("results/normalized_summary_report.json", "w", encoding="utf-8") as f:
        json.dump(report, f, ensure_ascii=False, indent=4)
    
    print("摘要报告已保存到 results/normalized_summary_report.json")
    
    # 创建人类可读的摘要报告
    human_report = f"""# 全球旅行建议数据摘要报告（含归一化风险等级）

## 报告概述
- 报告生成时间: {report["report_date"]}
- 数据来源: {", ".join(report["data_sources"])}
- 总国家数量: {report["total_countries"]}
- 风险等级分布:
  - 低风险国家: {risk_level_counts[1]} 个
  - 中等风险国家: {risk_level_counts[2]} 个
  - 高风险国家: {risk_level_counts[3]} 个
  - 极高风险国家: {risk_level_counts[4]} 个

## 极高风险国家
以下国家的平均风险等级为"极高风险"，建议避免前往:
{", ".join(countries_by_risk[4][:20])}{"..." if len(countries_by_risk[4]) > 20 else ""}

## 数据说明
1. 本数据集整合了美国、英国、加拿大、澳大利亚和新西兰五个国家的官方旅行建议
2. 每个国家的旅行建议包含原始风险等级、更新时间和归一化风险等级
3. 归一化风险等级分为四级：低风险、中等风险、高风险、极高风险
4. 国家的平均风险等级是基于所有可用数据源的归一化风险等级计算得出

## 数据使用建议
1. 在规划旅行时，建议参考归一化风险等级进行初步筛选
2. 对于高风险和极高风险国家，建议谨慎考虑是否前往
3. 本数据仅供参考，实际旅行决策应以官方最新发布为准
4. 建议定期更新数据，确保获取最新的旅行建议

## 数据样例
以下是不同风险等级国家的旅行建议数据样例（仅供参考）:
"""
    
    # 添加数据样例
    for level in [1, 2, 3, 4]:
        if countries_by_risk[level]:
            sample_country = countries_by_risk[level][0]
            risk_text = ""
            if level == 1:
                risk_text = "低风险"
            elif level == 2:
                risk_text = "中等风险"
            elif level == 3:
                risk_text = "高风险"
            else:
                risk_text = "极高风险"
            
            human_report += f"\n### {sample_country} ({risk_text})\n"
            for source, source_data in data[sample_country].items():
                if isinstance(source_data, dict) and "advisory_level" in source_data and "normalized_text" in source_data:
                    human_report += f"- {source}: {source_data['advisory_level']} → {source_data['normalized_text']} (更新时间: {source_data.get('last_update', 'N/A')})\n"
    
    # 保存人类可读的摘要报告
    with open("results/normalized_summary_report.md", "w", encoding="utf-8") as f:
        f.write(human_report)
    
    print("人类可读的摘要报告已保存到 results/normalized_summary_report.md")
    return True

if __name__ == "__main__":
    # 添加归一化风险等级
    normalized_data = normalize_data()
    
    if normalized_data:
        # 创建归一化标准文档
        create_normalization_standard_doc()
        
        # 创建摘要报告
        create_summary_report(normalized_data)
        
        print("所有任务已完成！")
    else:
        print("处理失败，请检查数据文件。")
