import json
import os

def check_json_structure():
    """
    检查整合后的JSON数据结构并修正
    """
    print("开始检查整合后的JSON数据结构...")
    
    # 读取整合后的JSON文件
    try:
        with open("results/integrated_travel_advisories.json", "r", encoding="utf-8") as f:
            data = json.load(f)
    except Exception as e:
        print(f"读取整合后的JSON文件时出错: {e}")
        return False
    
    # 检查数据结构
    modified = False
    for country, country_data in data.items():
        if isinstance(country_data, list):
            print(f"国家 {country} 的数据结构为列表，需要修正")
            # 将列表转换为字典
            new_country_data = {}
            for source_idx, source_data in enumerate(country_data):
                if isinstance(source_data, dict) and "source" in source_data:
                    source_name = source_data["source"]
                    new_country_data[source_name] = source_data
                else:
                    # 如果没有source字段，使用索引作为键
                    new_country_data[f"Unknown_Source_{source_idx}"] = source_data
            
            # 更新数据
            data[country] = new_country_data
            modified = True
    
    if modified:
        # 保存修正后的数据
        with open("results/integrated_travel_advisories_fixed.json", "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False, indent=4)
        print("数据结构已修正，保存到 results/integrated_travel_advisories_fixed.json")
        return "results/integrated_travel_advisories_fixed.json"
    else:
        print("数据结构检查完成，无需修正")
        return "results/integrated_travel_advisories.json"

def validate_data(file_path):
    """
    校验整合后的JSON数据完整性和准确性
    """
    print(f"开始校验JSON数据: {file_path}")
    
    # 读取整合后的JSON文件
    try:
        with open(file_path, "r", encoding="utf-8") as f:
            data = json.load(f)
    except Exception as e:
        print(f"读取JSON文件时出错: {e}")
        return False
    
    # 检查数据源
    sources = ["US", "UK", "Canada", "Australia", "NewZealand"]
    
    # 统计信息
    total_countries = len(data)
    countries_with_all_sources = 0
    countries_with_missing_sources = {}
    countries_with_alternative_data = {}
    
    # 校验每个国家的数据
    for country, country_data in data.items():
        if not isinstance(country_data, dict):
            print(f"警告: 国家 {country} 的数据不是字典格式")
            continue
            
        country_sources = set(country_data.keys())
        missing = [source for source in sources if source not in country_sources]
        
        if not missing:
            countries_with_all_sources += 1
        else:
            countries_with_missing_sources[country] = missing
        
        # 检查是否使用了备用数据
        for source, source_data in country_data.items():
            if isinstance(source_data, dict) and "note" in source_data and "备用数据" in source_data.get("note", ""):
                if country not in countries_with_alternative_data:
                    countries_with_alternative_data[country] = []
                countries_with_alternative_data[country].append(source)
    
    # 输出校验结果
    print(f"校验完成，共有 {total_countries} 个国家的数据")
    print(f"其中 {countries_with_all_sources} 个国家在所有数据源中都有数据")
    print(f"有 {len(countries_with_missing_sources)} 个国家在某些数据源中缺失数据")
    print(f"有 {len(countries_with_alternative_data)} 个国家使用了备用数据")
    
    # 保存校验结果
    validation_result = {
        "total_countries": total_countries,
        "countries_with_all_sources": countries_with_all_sources,
        "countries_with_missing_sources": countries_with_missing_sources,
        "countries_with_alternative_data": countries_with_alternative_data
    }
    
    with open("results/validation_result.json", "w", encoding="utf-8") as f:
        json.dump(validation_result, f, ensure_ascii=False, indent=4)
    
    print("校验结果已保存到 results/validation_result.json")
    return True

if __name__ == "__main__":
    # 先检查并修正数据结构
    fixed_file_path = check_json_structure()
    
    # 然后校验数据
    validate_data(fixed_file_path)
