import requests
from bs4 import BeautifulSoup
import json
import datetime
import time
import random

def get_us_travel_advisories():
    """
    爬取美国国务院旅行建议数据
    """
    print("开始爬取美国旅行建议数据...")
    url = "https://travel.state.gov/content/travel/en/traveladvisories/traveladvisories.html/"
    
    # 添加请求头，模拟浏览器访问
    headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
        'Accept-Language': 'en-US,en;q=0.5',
        'Connection': 'keep-alive',
        'Upgrade-Insecure-Requests': '1',
    }
    
    try:
        response = requests.get(url, headers=headers)
        response.raise_for_status()
        
        # 保存原始HTML以备后续分析
        with open("us_raw_data.html", "w", encoding="utf-8") as f:
            f.write(response.text)
            
        print(f"美国旅行建议数据已保存到 us_raw_data.html")
        
        # 解析HTML
        soup = BeautifulSoup(response.text, 'html.parser')
        
        # 查找包含旅行建议的表格
        advisory_table = soup.find('table', class_='TravelAdvisories')
        
        if not advisory_table:
            print("未找到旅行建议表格，尝试其他选择器...")
            # 保存当前时间作为更新时间
            current_time = datetime.datetime.now().strftime("%Y-%m-%d")
            return {"source": "US", "fetch_date": current_time, "data": [], "error": "Table not found"}
        
        advisories = []
        
        # 遍历表格行
        rows = advisory_table.find_all('tr')
        for row in rows[1:]:  # 跳过表头
            cols = row.find_all('td')
            if len(cols) >= 2:
                country = cols[0].text.strip()
                level_text = cols[1].text.strip()
                
                # 提取更新日期，如果有的话
                date_col = cols[2].text.strip() if len(cols) > 2 else ""
                
                advisories.append({
                    "country": country,
                    "advisory_level": level_text,
                    "last_update": date_col
                })
        
        # 保存当前时间作为抓取时间
        current_time = datetime.datetime.now().strftime("%Y-%m-%d")
        
        result = {
            "source": "US",
            "fetch_date": current_time,
            "data": advisories
        }
        
        # 保存为JSON文件
        with open("us_advisories.json", "w", encoding="utf-8") as f:
            json.dump(result, f, ensure_ascii=False, indent=4)
            
        print(f"已提取 {len(advisories)} 条美国旅行建议数据")
        return result
        
    except Exception as e:
        print(f"爬取美国旅行建议数据时出错: {str(e)}")
        # 保存当前时间作为更新时间
        current_time = datetime.datetime.now().strftime("%Y-%m-%d")
        return {"source": "US", "fetch_date": current_time, "data": [], "error": str(e)}

if __name__ == "__main__":
    get_us_travel_advisories()
