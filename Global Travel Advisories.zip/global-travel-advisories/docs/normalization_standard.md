# 旅行风险等级归一化标准

## 归一化等级定义

我们将各数据源的风险等级归一化为以下四个标准等级：

1. **低风险：建议正常出行** - 目的地安全状况良好，可以正常旅行，注意基本安全即可。
2. **中等风险：建议提高警觉** - 目的地存在一定安全隐患，旅行时需提高警惕，注意个人安全。
3. **高风险：建议谨慎出行** - 目的地存在较高安全风险，建议重新考虑旅行计划，如必须前往应采取额外安全措施。
4. **极高风险：建议避免出行** - 目的地存在严重安全威胁，强烈建议避免前往。

## 各数据源风险等级映射关系

### 美国国务院旅行建议 (US)

| 原始风险等级 | 归一化等级 | 归一化描述 |
|------------|-----------|----------|
| Level 1 / Exercise Normal Precautions | 1 | 低风险：建议正常出行 |
| Level 2 / Exercise Increased Caution | 2 | 中等风险：建议提高警觉 |
| Level 3 / Reconsider Travel | 3 | 高风险：建议谨慎出行 |
| Level 4 / Do Not Travel | 4 | 极高风险：建议避免出行 |

### 英国外交、联邦和发展办公室旅行建议 (UK)

| 原始风险等级 | 归一化等级 | 归一化描述 |
|------------|-----------|----------|
| See our travel advice | 1 | 低风险：建议正常出行 |
| Advise against all but essential travel | 3 | 高风险：建议谨慎出行 |
| Advise against all travel | 4 | 极高风险：建议避免出行 |

### 加拿大旅行建议 (Canada)

| 原始风险等级 | 归一化等级 | 归一化描述 |
|------------|-----------|----------|
| Exercise normal security precautions | 1 | 低风险：建议正常出行 |
| Exercise a high degree of caution | 2 | 中等风险：建议提高警觉 |
| Avoid non-essential travel | 3 | 高风险：建议谨慎出行 |
| Avoid all travel | 4 | 极高风险：建议避免出行 |

### 澳大利亚旅行建议 (Australia)

| 原始风险等级 | 归一化等级 | 归一化描述 |
|------------|-----------|----------|
| Exercise normal safety precautions | 1 | 低风险：建议正常出行 |
| Exercise a high degree of caution | 2 | 中等风险：建议提高警觉 |
| Reconsider your need to travel | 3 | 高风险：建议谨慎出行 |
| Do not travel | 4 | 极高风险：建议避免出行 |

### 新西兰旅行建议 (NewZealand)

| 原始风险等级 | 归一化等级 | 归一化描述 |
|------------|-----------|----------|
| Exercise normal safety precautions | 1 | 低风险：建议正常出行 |
| Exercise increased caution | 2 | 中等风险：建议提高警觉 |
| Avoid non-essential travel | 3 | 高风险：建议谨慎出行 |
| Do not travel | 4 | 极高风险：建议避免出行 |

## 通用关键词匹配规则

对于未明确定义的风险等级表述，系统使用以下关键词进行匹配：

### 低风险关键词
`normal`, `safe`, `low risk`, `no restriction`, `no advisory`, `exercise normal`

### 中等风险关键词
`caution`, `increased`, `vigilant`, `aware`, `alert`, `exercise caution`, `high degree`

### 高风险关键词
`reconsider`, `avoid non`, `essential`, `necessary`, `avoid unnecessary`, `reconsidering`

### 极高风险关键词
`do not`, `avoid all`, `against all`, `no travel`, `not travel`, `extreme`


## 数据结构说明

在JSON数据中，每个国家的每个数据源都添加了以下两个字段：

1. `normalized_level`: 归一化后的风险等级数值（1-4）
2. `normalized_text`: 归一化后的风险等级文本描述

示例：
```json
{
  "Afghanistan": {
    "US": {
      "advisory_level": "Level 4: Do Not Travel",
      "last_update": "2023-07-10",
      "source": "US",
      "normalized_level": 4,
      "normalized_text": "极高风险：建议避免出行"
    }
  }
}
```

## 注意事项

1. 由于各数据源使用不同的风险评估体系，归一化过程可能存在一定的主观判断
2. 对于无法明确匹配的风险等级，系统会使用通用关键词规则进行匹配
3. 如果仍无法匹配，将默认归类为"中等风险"
4. 建议同时参考原始风险等级和归一化风险等级进行决策
