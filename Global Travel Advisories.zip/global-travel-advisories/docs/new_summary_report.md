# 全球旅行建议数据摘要报告

## 报告概述
- 报告生成时间: 2025-05-25 05:25:42
- 数据来源: 美国, 英国, 加拿大, 澳大利亚, 新西兰
- 总国家数量: 476
- 在所有数据源中都有数据的国家数量: 0
- 在某些数据源中缺失数据的国家数量: 476
- 使用备用数据的国家数量: 0

## 高风险国家
以下国家在至少3个数据源中被评为最高风险级别:
Ukraine, Burkina Faso, Mali, Belarus, Iraq, North Korea, Myanmar, Venezuela, Haiti, Libya, Central African Republic, Syria, Russia, Afghanistan, Lebanon, Yemen, South Sudan, Iran, Somalia, Niger, Sudan

## 数据说明
1. 本数据集整合了美国、英国、加拿大、澳大利亚和新西兰五个国家的官方旅行建议
2. 每个国家的旅行建议包含风险等级和更新时间
3. 由于各国使用不同的风险等级系统，数据未进行归一化处理
4. 部分数据源（如澳大利亚和新西兰）使用了备用数据，可能与官方数据有所差异

## 数据使用建议
1. 在规划旅行时，建议参考多个数据源的旅行建议
2. 对于高风险国家，建议谨慎考虑是否前往
3. 本数据仅供参考，实际旅行决策应以官方最新发布为准
4. 建议定期更新数据，确保获取最新的旅行建议

## 数据样例
以下是部分国家的旅行建议数据样例（仅供参考）:

### Indonesia
- UK: Warning
    FCDO advises against all travel to parts of Indonesia. (更新时间: )
- Canada: Exercise a high degree of caution (with regional advisories) (更新时间: 2025-05-21 13:56:22)
- Australia: Exercise a high degree of caution (更新时间: 2025-05-25)
- NewZealand: Exercise increased caution (更新时间: 2025-05-25)

### Luxembourg Travel Advisory
- US: Error fetching details (更新时间: )

### St Helena, Ascension and Tristan da Cunha
- UK: Information available on country page (更新时间: )

### Ukraine
- UK: Warning
    FCDO advises against all travel to parts of Ukraine. (更新时间: )
- Canada: Avoid all travel (更新时间: 2025-05-21 13:56:22)
- Australia: Do not travel (更新时间: 2025-05-25)
- NewZealand: Do not travel (更新时间: 2025-05-25)

### Uganda Travel Advisory
- US: Error fetching details (更新时间: )
