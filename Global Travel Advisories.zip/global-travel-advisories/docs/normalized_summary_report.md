# 全球旅行建议数据摘要报告（含归一化风险等级）

## 报告概述
- 报告生成时间: 2025-05-25 05:39:18
- 数据来源: 美国, 英国, 加拿大, 澳大利亚, 新西兰
- 总国家数量: 476
- 风险等级分布:
  - 低风险国家: 83 个
  - 中等风险国家: 352 个
  - 高风险国家: 13 个
  - 极高风险国家: 28 个

## 极高风险国家
以下国家的平均风险等级为"极高风险"，建议避免前往:
Ukraine, Burkina Faso, Democratic Republic of Congo (Kinshasa), Mali, Belarus, Iraq, Israel, North Korea, Myanmar, Venezuela, Haiti, Western Sahara, Libya, Central African Republic, Syria, Russia, Afghanistan, Lebanon, Democratic Republic of the Congo, Yemen...

## 数据说明
1. 本数据集整合了美国、英国、加拿大、澳大利亚和新西兰五个国家的官方旅行建议
2. 每个国家的旅行建议包含原始风险等级、更新时间和归一化风险等级
3. 归一化风险等级分为四级：低风险、中等风险、高风险、极高风险
4. 国家的平均风险等级是基于所有可用数据源的归一化风险等级计算得出

## 数据使用建议
1. 在规划旅行时，建议参考归一化风险等级进行初步筛选
2. 对于高风险和极高风险国家，建议谨慎考虑是否前往
3. 本数据仅供参考，实际旅行决策应以官方最新发布为准
4. 建议定期更新数据，确保获取最新的旅行建议

## 数据样例
以下是不同风险等级国家的旅行建议数据样例（仅供参考）:

### Micronesia (FSM) (低风险)
- Canada: Take normal security precautions → 低风险：建议正常出行 (更新时间: 2025-05-21 13:56:22)

### Indonesia (中等风险)
- UK: Warning
    FCDO advises against all travel to parts of Indonesia. → 极高风险：建议避免出行 (更新时间: )
- Canada: Exercise a high degree of caution (with regional advisories) → 中等风险：建议提高警觉 (更新时间: 2025-05-21 13:56:22)
- Australia: Exercise a high degree of caution → 中等风险：建议提高警觉 (更新时间: 2025-05-25)
- NewZealand: Exercise increased caution → 中等风险：建议提高警觉 (更新时间: 2025-05-25)

### Cameroon (高风险)
- UK: Warning
    FCDO advises against all travel to parts of Cameroon. → 极高风险：建议避免出行 (更新时间: )
- Canada: Exercise a high degree of caution (with regional advisories) → 中等风险：建议提高警觉 (更新时间: 2025-05-21 14:06:18)
- Australia: Reconsider your need to travel → 高风险：建议谨慎出行 (更新时间: 2025-05-25)
- NewZealand: Avoid non-essential travel → 高风险：建议谨慎出行 (更新时间: 2025-05-25)

### Ukraine (极高风险)
- UK: Warning
    FCDO advises against all travel to parts of Ukraine. → 极高风险：建议避免出行 (更新时间: )
- Canada: Avoid all travel → 极高风险：建议避免出行 (更新时间: 2025-05-21 13:56:22)
- Australia: Do not travel → 极高风险：建议避免出行 (更新时间: 2025-05-25)
- NewZealand: Do not travel → 极高风险：建议避免出行 (更新时间: 2025-05-25)
