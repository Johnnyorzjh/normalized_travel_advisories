# 全球旅行建议数据集

本项目收集并整合了来自美国、英国、加拿大、澳大利亚和新西兰五个国家的官方旅行建议数据，并提供了风险等级归一化处理。

## 项目概述

全球旅行建议数据集提供了全球476个国家和地区的旅行风险评估，数据来源于五个主要英语国家的官方旅行建议网站。本项目不仅保留了原始风险等级描述，还提供了统一的四级风险评估标准，便于跨国比较和分析。

## 数据来源

- 美国：[https://travel.state.gov/content/travel/en/traveladvisories/traveladvisories.html/](https://travel.state.gov/content/travel/en/traveladvisories/traveladvisories.html/)
- 英国：[https://www.gov.uk/foreign-travel-advice](https://www.gov.uk/foreign-travel-advice)
- 加拿大：[https://travel.gc.ca/travelling/advisories](https://travel.gc.ca/travelling/advisories)
- 澳大利亚：[https://www.smartraveller.gov.au/destinations](https://www.smartraveller.gov.au/destinations)
- 新西兰：[https://www.safetravel.govt.nz/destinations](https://www.safetravel.govt.nz/destinations)

## 目录结构

```
global-travel-advisories/
├── data/                      # 数据文件
│   ├── raw_data/              # 原始数据文件
│   ├── integrated_travel_advisories.json  # 整合后的数据
│   └── normalized_travel_advisories.json  # 归一化后的数据
├── docs/                      # 文档
│   ├── normalization_standard.md          # 归一化标准文档
│   ├── normalized_summary_report.md       # 归一化数据摘要报告
│   └── summary_report.md                  # 原始数据摘要报告
└── scripts/                   # 脚本文件
    ├── reintegrate_data.py               # 数据整合脚本
    ├── normalize_levels.py               # 风险等级归一化脚本
    └── ...                               # 其他脚本文件
```

## 风险等级归一化

为便于比较不同国家的旅行建议，本项目将各数据源的风险等级归一化为四个标准等级：

1. **低风险：建议正常出行** - 目的地安全状况良好，可以正常旅行，注意基本安全即可。
2. **中等风险：建议提高警觉** - 目的地存在一定安全隐患，旅行时需提高警惕，注意个人安全。
3. **高风险：建议谨慎出行** - 目的地存在较高安全风险，建议重新考虑旅行计划，如必须前往应采取额外安全措施。
4. **极高风险：建议避免出行** - 目的地存在严重安全威胁，强烈建议避免前往。

详细的归一化标准请参见 [docs/normalization_standard.md](docs/normalization_standard.md)。

## 数据格式

归一化后的JSON数据格式示例：

```json
{
  "Afghanistan": {
    "US": {
      "advisory_level": "Level 4: Do Not Travel",
      "last_update": "2023-07-10",
      "source": "US",
      "normalized_level": 4,
      "normalized_text": "极高风险：建议避免出行"
    },
    "UK": {
      "advisory_level": "The FCDO advises against all travel to Afghanistan",
      "last_update": "2023-06-28",
      "source": "UK",
      "normalized_level": 4,
      "normalized_text": "极高风险：建议避免出行"
    }
    // 其他数据源...
  }
  // 其他国家...
}
```

## 使用说明

1. `data/normalized_travel_advisories.json` 包含完整的归一化旅行建议数据
2. `docs/normalized_summary_report.md` 提供了数据摘要和高风险国家列表
3. 可以使用 `scripts/normalize_levels.py` 脚本更新归一化标准或处理新数据

## 注意事项

1. 由于各数据源使用不同的风险评估体系，归一化过程可能存在一定的主观判断
2. 本数据仅供参考，实际旅行决策应以官方最新发布为准
3. 建议定期更新数据，确保获取最新的旅行建议

## 许可证

本项目采用 MIT 许可证，详见 [LICENSE](LICENSE) 文件。
